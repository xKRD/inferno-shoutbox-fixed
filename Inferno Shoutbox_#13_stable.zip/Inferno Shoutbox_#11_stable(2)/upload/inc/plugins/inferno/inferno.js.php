<?php
define('IN_MYBB', 1);
define("NO_ONLINE", 1);

require_once '../../../global.php';
require_once MYBB_ROOT . 'inc/plugins/inferno/class_core.php';
require_once(MYBB_ROOT . 'inc/plugins/inferno/config.php');
$twich_mode = (int)$inferno_config['twich_mode'];
$vote_ban = (int)$inferno_config['vote_ban'];
$inferno = inferno_shoutbox::get_instance();
$userinfo = $inferno->userinfo;
$lang->load('inferno', false, true);
header('Content-Type: text/javascript');
?>

/**
 *
 * Inferno Shoutbox Lite JavaScript File
 *
 * Inferno Shoutbox created by Mattbox Solutions
 * ectomatt @ mybb.com
 * u mirin?
 *
 */
inferno = function()
{
	this.url = 'infernoshout.php';
	this.refresh_rate = <?php echo intval($settings['inferno_js_refresh'] * 1000); ?>;
	this.shout_max_chars = <?php echo $settings['inferno_shout_max_chars']; ?>;
	this.shout_entry = null;
	this.post_key = '';
	this.interval = null;
	this.shoutbox_content = null;
	this.active_user_number = null;
	this.alert_div = false;
	this.smiley_div = false;
	this.styles = {
		'bold': <?php echo ($userinfo['bold']) ? 'true' : 'false'; ?>,
		'italic': <?php echo ($userinfo['italic']) ? 'true' : 'false'; ?>,
		'underline': <?php echo ($userinfo['underline']) ? 'true' : 'false'; ?>,
		'color': '<?php echo ($userinfo['color']); ?>',
		'font': '<?php echo ($userinfo['font']); ?>'
	}
	this.style_update = false;
	this.linkbar = false;
	this.private_chats = new Array();
	this.whisper_chats = new Array();
	this.tab = null;
	this.editdiv = null;
	this.editdivtext = null;
	this.editshoutid = null;
	this.editshout = null;
	//this.shoutwait = <?php echo $settings['inferno_shoutbox_flood']; ?>;
	this.shoutwait = 0;
	this.lastshout = null;
	this.idlesetting = <?php echo $settings['inferno_idle_timeout'] * 60; ?>;
	this.idletimeout = time() + this.idlesetting;
	this.idlealert = false;
	this.idleinterval = null;
	this.asc = <?php echo $settings['inferno_shout_order'] ? 'false' : 'true'; ?>

	this.anus = <?php echo $settings['inferno_shoutbox_anus'] ? 'true' : 'false'; ?>;
	this.last_anus = time();
	this.anus_time = null;

	this.manage_anus = function()
	{
		// peek inside the anus and save its contents
		this.open_anus();

		if (this.anus_time > this.last_anus)
		{
			return true;
		}
		return false;
	}

	this.open_anus = function()
	{
		jQuery.ajax({
			type: 'GET',
			url: this.url + '?action=openanus' + inferno.screw_ie(),
			success: function(transport) {
				inferno.anus_time = transport;
			},
			error: function() { inferno.alert('<?php echo $lang->isb_opt_error; ?>'); }
		});
	}

	this.twich_mode = function()
	{
		jQuery.ajax({
			type: 'GET',
			url: this.url + '?action=twich_mode',
			success: function(request) {
				inferno.alert(request);
			},
			error: function() { inferno.alert('<?php echo $lang->isb_opt_error; ?>'); }
		});
	}

	this.vote_ban = function()
	{
		jQuery.ajax({
			type: 'GET',
			url: this.url + '?action=vote_ban',
			success: function(request) {
				inferno.alert(request);
			},
			error: function() { inferno.alert('<?php echo $lang->isb_opt_error; ?>'); }
		});
	}
	
	this.close_anus = function()
	{
		this.last_anus = time();
	}

	this.is_idle = function()
	{
		return (time() > this.idletimeout) ? true : false;
	}

	this.clear_idle = function()
	{
		this.clear_alert();
		this.update_idle_time();

		if (this.tab > 0) {
    		this.load_private_shouts(this.tab);
    	} else {
    		this.load_shouts();
    	}
	}

	this.update_idle_time = function()
	{
		this.idlealert = false;
		this.idletimeout = time() + this.idlesetting;
		return true;
	}

	// fix for IE's stupid ass caching ajax requests
	this.screw_ie = function()
	{
		return '&t=' + new Date().getTime();
	}

	this.init = function()
{
	if (this.interval !== null)
	{
		clearInterval(this.interval);
	}

	// Get CSRF token - try multiple methods
	var post_key_field = document.getElementById('my_post_key');
	if (post_key_field && post_key_field.value) {
		this.post_key = post_key_field.value;
	} else {
		// Fallback: try to get from any form on the page
		var forms = document.getElementsByTagName('form');
		for (var i = 0; i < forms.length; i++) {
			var key_input = forms[i].querySelector('input[name="my_post_key"]');
			if (key_input && key_input.value) {
				this.post_key = key_input.value;
				break;
			}
		}
	}

	this.idleinterval = setInterval(function() {
			if (inferno.is_idle())
			{
				if (!inferno.idlealert){
					inferno.alert('<?php echo $lang->isb_reconect; ?>', false);
				}
			}
		}, 1000);

		this.shout_entry = document.getElementById('inferno_shout_entry');
		this.shoutbox_content = document.getElementById('inferno_content');
		this.active_user_number = document.getElementById('inferno_active_users');
		this.alert_div = document.getElementById('inferno_alert');
		this.smiley_div = document.getElementById('inferno_smilies');
		this.linkbar = document.getElementById('inferno_links');
		this.editdiv = document.getElementById('inferno_edit_shout');
		this.editdivtext = document.getElementById('inferno_update_shout');

		if (this.tab != -1)
		{
			this.tab = -1;
			this.shoutbox_content.innerHTML = '<?php echo $lang->isb_loading; ?>';
			this.load_shouts();
		}

		if (this.tab == -1)
		{
			this.interval = setInterval(function() {
				if (inferno.tab == -1)
				{
					if (inferno.is_idle() == false)
					{
						if (inferno.anus)
						{
							if (inferno.manage_anus())
							{
								inferno.load_shouts();
								inferno.close_anus();
							}
						}
						else
						{
							inferno.load_shouts();
						}
					}
				}
			}, this.refresh_rate);
			inferno.update_idle_time();
		}
	}

	this.edit_shout = function(id)
	{
		this.editshoutid = id;
		this.get_shout(id);
	}

	this.get_shout = function(id)
	{
		jQuery.ajax({
			type: 'GET',
			url: this.url + '?action=getshout&id=' + id + inferno.screw_ie(),
			success: function(transport) {
				if (transport != '')
				{
					inferno.editshout = JSON.parse(transport);
					inferno.display_update();
					inferno.update_idle_time();
				}
			},
			error: function() { inferno.alert('<?php echo $lang->isb_shout_error; ?>'); }
		});
	}

	this.display_update = function()
	{
		obj = this.editshout;
		editdiv = this.editdiv;
		editdivtext = this.editdivtext;
		editdiv.style.display = 'block';
		editdivtext.value = this.trim(obj.shout); //.trim();
	}

	this.update_shout = function()
{
	sid = this.editshoutid;
	editdivtext = this.editdivtext;
	shout = this.trim(editdivtext.value); //.trim();
	condition = this.is_valid_shout(shout);

	if (condition == true)
	{
		var options = {
		    type: 'post',
			url: this.url + '?action=updateshout',
		    data: {sid: sid, shout: shout, my_post_key: this.post_key},
		    success: function() {
			    	inferno.cancel();
			    	if (inferno.tab > 0) {
			    		inferno.load_private_shouts(inferno.tab);
			    	} else {
			    		inferno.load_shouts();
			    	}
			    	inferno.update_idle_time();
				}
			};
			jQuery.ajax(options);
		}
		else
		{
			this.alert(condition);
		}
	}

	this.delete_shout = function()
{
	sid = this.editshoutid;
	var options = {
	    type: 'POST',
		url: this.url + '?action=deleteshout',
	    data: {sid: sid, my_post_key: inferno.post_key},
	    success: function() {
		    	inferno.alert('<?php echo $lang->isb_shout_cleaned; ?>');
		    	inferno.cancel();
		    	if (inferno.tab > 0) {
		    		inferno.load_private_shouts(inferno.tab);
		    	} else {
		    		inferno.load_shouts();
		    	}
		    }
		};
		jQuery.ajax(options);
	}

	this.remove_shout = function(sid)
	{
		$.get(this.url + '?action=removeshout&sid='+sid, function(data){
			inferno.alert('<?php echo $lang->isb_shout_cleaned; ?>');
		    if (inferno.tab > 0) {
		    	inferno.load_private_shouts(inferno.tab);
		    } else {
		    	inferno.load_shouts();
		    }			
		})
	}

	this.remove_whisper = function(sid)
	{
		$.get(this.url + '?action=removeshout&sid='+sid, function(data){
			inferno.alert('<?php echo $lang->isb_shout_cleaned; ?>');
		    if (inferno.tab > 0) {
		    	inferno.load_whispers_shouts(inferno.tab);
		    } else {
		    	inferno.load_shouts();
		    }			
		})
	}
	
	this.ban_user = function(uid, uname)
	{
		$.get(this.url + '?action=ban_user&uid='+uid+'&uname='+uname, function(data){
			inferno.alert(uname+'<?php echo $lang->isb_user_banned; ?>');
			inferno.load_shouts();
		})
	}
	
	this.cancel = function()
	{
		this.editshout = null;
		this.editdiv.style.display = 'none';
	}

	this.update_style = function(style, obj)
	{
		if (style == 'bold' || style == 'italic' || style == 'underline') {
			vals = {
				bold: 'B',
				italic: 'I',
				underline: 'U'
			}
			if (obj.value.indexOf('*') == -1) {
				obj.value += '*';
				this.styles[style] = true;
				this.update_entry_style(style, true);
			} else {
				obj.value = vals[style];
				this.styles[style] = false;
				this.update_entry_style(style, false);
			}
		} else {
			this.styles[style] = obj.value;
			this.update_entry_style(style, obj.value);
		}
		this.alert('<?php echo $lang->isb_shout_change_style; ?>');
		this.style_update = true;
	}

	this.update_entry_style = function(style, value)
	{
		entry = this.shout_entry;
		switch (style)
		{
			case 'bold':
				entry.style.fontWeight = (value) ? 'bold' : '';
				break;
			case 'italic':
				entry.style.fontStyle = (value) ? 'italic' : '';
				break;
			case 'underline':
				entry.style.textDecoration = (value) ? 'underline' : '';
				break;
			case 'font':
				entry.style.fontFamily = (value == 'Default') ? '' : value;
				break;
			case 'color':
				entry.style.color = (value == 'Default') ? '' : value;
		}
	}

	this.insertUser = function(name)
	{
		if (name)
		{
			$(".sbcount").hide();
			this.shout_entry.value += ' @"' + name + '" ';
			document.newshout.newshout.focus();
		}
	}

	this.get_modal_user = function(sid,uid)
	{
		if (sid)
		{
			$(".items").remove();
			$.get("infernoshout.php?action=getUserModals&sid="+sid+"&uid="+uid, function(data){
				$(".shoutcount"+sid).prepend(data);
			});
			$(".shoutcount"+sid).css({"display":"block"}).fadeIn("slow");
		}
	}

	this.remove_modal_user = function(sid)
	{
		if (sid)
		{
			//$(".shoutcount"+sid).fadeOut();
			$("ul.sbcount").hide();
			$(".items").remove();
		}
	}
	
	this.add_private_chat = function(uid, name)
	{
		if (!in_array(uid, this.private_chats))
		{
			this.private_chats.push(uid);
			this.linkbar.innerHTML += '<div id="inferno_pm_chat_' + uid + '"><a href="#" onclick="javascript: inferno.open_chat(' + uid + '); return false;">' 
			+ name + 
			'</a> [<a href="#" onclick="javascript: inferno.close_chat(' + uid + '); return false;">X</a>]</div>';
		}
		this.open_chat(uid);
	}
	
	this.add_whisper_chat = function(uid, name)
	{
		if (!in_array(uid, this.whisper_chats))
		{
			this.whisper_chats.push(uid);
			this.linkbar.innerHTML += '<div id="inferno_whisper_chat_' + uid + '"><a href="#" onclick="javascript: inferno.open_whisper(' + uid + '); return false;">' 
			+ name + 
			'</a> [<a href="#" onclick="javascript: inferno.close_whisper(' + uid + '); return false;">X</a>]</div>';
		}		
		this.open_whisper(uid);
	}
	
	this.add_whisper = function(uid)
	{
		if (uid)
		{
			$(".sbcount").hide();
			this.shout_entry.value += '/whisper ' + uid + '; ';
			document.newshout.newshout.focus();
		}		
	}
	
	this.add_private_shout = function(uid)
	{
		if (uid)
		{
			$(".sbcount").hide();
			this.shout_entry.value += '/pm ' + uid + '; ';
			document.newshout.newshout.focus();
		}		
	}
	
	this.open_chat = function(uid)
	{
		if (this.tab == uid)
		{
			return false;
		}
		this.load_private_shouts(uid);
	}

	this.open_whisper = function(uid)
	{
		if (this.tab == uid)
		{
			return false;
		}
		this.load_whispers_shouts(uid);
	}
	
	this.close_chat = function(uid)
	{
		tempdiv = document.getElementById('inferno_pm_chat_' + uid);
		tempdiv.parentNode.removeChild(tempdiv);
		remove_array_piece(uid, this.private_chats);
		this.init();
	}

	this.close_whisper = function(uid)
	{
		tempdiv = document.getElementById('inferno_whisper_chat_' + uid);
		tempdiv.parentNode.removeChild(tempdiv);
		remove_array_piece(uid, this.whisper_chats);		
		this.init();
	}
	
	this.submit_styles = function()
	{
		if (this.style_update)
		{
			s = this.styles;
			s = JSON.stringify(s);

			var options = {
			    type: 'post',
				url: this.url + '?action=updatestyles',
			    data: 'styles=' + s
			};

			jQuery.ajax(options);
			this.style_update = false;
			this.alert('<?php echo $lang->isb_shout_change_style_update; ?>');
		}
	}

	this.trim = function(string)
	{
		return string.replace(/^\s+|\s+$/g, '');
	}

	this.submit_shout = function()
	{
		lastshout = this.lastshout;
		now = time();
		<?php
		if($twich_mode == 0)
			$wait = "wait = lastshout + (this.shoutwait);
		";
		else
			$wait = "wait = lastshout;
		";
		echo $wait;
		?>

		shout = this.trim(this.shout_entry.value); // .trim();
		let styles = this.styles; 
		condition = this.is_valid_shout(shout);
		if (this.tab == -1 || this.tab == 0) {
			params = {shout: shout, styles: styles};
		} else {
			var whisper = $("#whisperid1").val();
			if(whisper == 1)
				params = {shout: shout, whisperid: this.tab, styles: styles};
			else	
				params = {shout: shout, pmid: this.tab, styles: styles};
		}

		if (condition == true)
		{
			if (!lastshout) {
				this.lastshout = now;
			} else {
				if (now < wait) {
					this.alert('<?php echo $lang->isb_shout_wait1; ?>' + (wait - now) + '<?php echo $lang->isb_shout_wait2; ?>' + ((wait - now == 1) ? '' : '<?php echo $lang->isb_shout_wait3; ?>') + '<?php echo $lang->isb_shout_wait4; ?>');
					return false;
				} else {
					this.lastshout = null;
				}
			}

			params.my_post_key = this.post_key;

var options = {
    type: 'POST',
    url: inferno.url + '?action=newshout',
    data: params,
    headers: {
        'X-Requested-With': 'XMLHttpRequest'
    },
				beforeSend: function(){
					$("#inferno_content").append('<div align="center" id="ldnt"><img src="images/spinner.gif" alt="Loading..." /></span>');
				},
			    success: function(res) {
					if(res)
					{
						$("#inferno_alert").html('<div class="inferno_alert_error" id="iadnt">'+res+'</span>');
						$("div#iadnt").fadeOut(10000);
					}
			    	inferno.submit_styles();
			    	if (inferno.tab > 0) {
						var whisper = $("#whisperid1").val();
						if(whisper == 1)
							inferno.load_whispers_shouts(inferno.tab);
						else
							inferno.load_private_shouts(inferno.tab);
			    	} else {
			    		inferno.load_shouts();
			    	}
			    	inferno.update_idle_time();
			    }
			};
			jQuery.ajax(options);
			$("div#ldnt").fadeOut(10000);
			inferno.clear_shout();
			console.log(inferno.url + '?action=newshout');
		}
		else
		{
			this.alert(condition);
		}
	}

	this.toggle_smilies = function()
	{
		smileydiv = this.smiley_div;

		if (smileydiv.innerHTML == '')
		{
			jQuery.ajax({
				type:'get',
				url: this.url + '?action=getsmilies',
				success: function(transport) {
					response = transport;
					if (response == '') {
						inferno.alert('<?php echo $lang->isb_shout_no_smilies; ?>');
					} else {
						smileydiv.innerHTML = response;
					}
				},
				error: function() { inferno.alert('<?php echo $lang->isb_shout_smilies_error; ?>'); }
			});
		}
		else
		{
			smileydiv.innerHTML = '';
		}
	}

	this.append = function(text)
	{
		entry = this.shout_entry;
		entry.value += ' ' + text;
		entry.value = this.trim(entry.value); //.trim();
	}

	this.alert = function(message, timeout)
	{
		timeout = (typeof timeout === "undefined") ? true : timeout;
		alertdiv = this.alert_div;
		alertdiv.className = 'inferno_alert_div';
		alertdiv.innerHTML = '<?php echo $lang->isb_shout_notice; ?>' + message;

		if (timeout)
		{
			clearTimeout(this.timeout);
			this.timeout = setTimeout(function(){
				inferno.clear_alert();
			}, 4000);
		}
	}

	this.clear_alert = function()
	{
		alertdiv.innerHTML = '';
		alertdiv.className = '';
	}

	this.is_valid_shout = function(shout)
	{
		if (shout.length > this.shout_max_chars)
		{
			return '<?php echo $lang->isb_shout_send_error1; ?>' + shout.length + '/' + this.shout_max_chars + '<?php echo $lang->isb_shout_send_error2; ?>';
		}
		if (shout.length == 0)
		{
			return '<?php echo $lang->isb_shout_send_error; ?>';
		}
		return true;
	}

	this.load_active_user_number = function(text)
	{
		spanid = this.active_user_number;
		spanid.innerHTML = text;
	}

	this.load_private_shouts = function (uid)
	{
		contentdiv = this.shoutbox_content;
		
		if (this.tab != uid)
		{
			clearInterval(this.interval);

			this.interval = setInterval(function() {
				if (inferno.is_idle() == false)
				{
					if (inferno.anus)
					{
						if (inferno.manage_anus())
						{
							inferno.load_private_shouts(uid);
							inferno.close_anus();
						}
					}
					else
					{
						inferno.load_private_shouts(uid);
					}
				}
			}, this.refresh_rate);

			contentdiv.innerHTML = '<?php echo $lang->isb_loading; ?>';
			this.tab = uid;
		}

		jQuery.ajax({
			type: 'GET',
			url: this.url + '?action=getshouts&id=' + uid + inferno.screw_ie(),
			success: function(transport) {
				response = transport;

				if (response.indexOf('<<~!PARSE_SHOUT!~>>') != -1) {
					active_users = response.substring(0, response.indexOf('<<~!PARSE_SHOUT!~>>'));
					inferno.load_active_user_number(active_users);
					contentdiv.innerHTML = response.substring(response.indexOf('<<~!PARSE_SHOUT!~>>') + '<<~!PARSE_SHOUT!~>>'.length, response.length);
				}
				inferno.update_idle_time();
			},
			error: function() { inferno.alert('<?php echo $lang->isb_shout_error_loading; ?>'); }
		});
	}

	this.load_shouts = function()
	{
		contentdiv = this.shoutbox_content;

		if (this.tab != -1)
		{
			contentdiv.innerHTML = '<?php echo $lang->isb_loading; ?>';
		}

		jQuery.ajax({
			type: "GET",
			url: this.url + '?action=getshouts' + inferno.screw_ie(),
			success: function(transport) {
				response = transport;

				if (response.indexOf('<<~!PARSE_SHOUT!~>>') != -1) {
					active_users = response.substring(0, response.indexOf('<<~!PARSE_SHOUT!~>>'));
					inferno.load_active_user_number(active_users);
					contentdiv.innerHTML = response.substring(response.indexOf('<<~!PARSE_SHOUT!~>>') + '<<~!PARSE_SHOUT!~>>'.length, response.length);
					if (inferno.asc)
					{
						contentdiv.scrollTop = contentdiv.scrollHeight;
					}
					$("#inferno_content").animate({ scrollTop: 0 }, "fast");
				}
			},
			error: function() { inferno.alert('<?php echo $lang->isb_shout_error_loading; ?>'); }
		});
	}

	this.load_whispers_shouts = function(uid)
	{
		contentdiv = this.shoutbox_content;
		
		if (this.tab != uid)
		{
			clearInterval(this.interval);

			this.interval = setInterval(function() {
				if (inferno.is_idle() == false)
				{
					if (inferno.anus)
					{
						if (inferno.manage_anus())
						{
							inferno.load_whispers_shouts(uid);
							inferno.close_anus();
						}
					}
					else
					{
						inferno.load_whispers_shouts(uid);
					}
				}
			}, this.refresh_rate);

			contentdiv.innerHTML = '<?php echo $lang->isb_loading; ?>';
			this.tab = uid;
		}

		jQuery.ajax({
			type: 'GET',
			url: this.url + '?action=getwhisper&uid=' + uid + inferno.screw_ie(),
			success: function(transport) {
				response = transport;

				if (response.indexOf('<<~!PARSE_SHOUT!~>>') != -1) {
					active_users = response.substring(0, response.indexOf('<<~!PARSE_SHOUT!~>>'));
					inferno.load_active_user_number(active_users);
					contentdiv.innerHTML = response.substring(response.indexOf('<<~!PARSE_SHOUT!~>>') + '<<~!PARSE_SHOUT!~>>'.length, response.length);
				}
				inferno.update_idle_time();
			},
			error: function() { inferno.alert('<?php echo $lang->isb_shout_error_loading; ?>'); }
		});
	}
	
	this.load_active_users = function()
	{
		if (this.tab != 0)
		{
			this.tab = 0;
			clearInterval(this.interval);
			contentdiv = this.shoutbox_content;
			contentdiv.innerHTML = '<?php echo $lang->isb_loading; ?>';

			jQuery.ajax({
				type: 'GET',
				url: this.url + '?action=getactiveusers' + inferno.screw_ie(),
				success: function(transport) {
					contentdiv.innerHTML = transport;
					inferno.update_idle_time();
				},
				error: function() { alert('<?php echo $lang->isb_shout_error_userlist; ?>'); }
			});
		}
	}

	this.clear_shout = function()
	{
		this.shout_entry.value = '';
		this.shout_entry.select();
	}
}

function in_array(needle, haystack)
{
	for (j = 0; j < haystack.length; j++)
	{
		if (needle === haystack[j])
		{
			return true;
		}
	}
	return false;
}

function remove_array_piece(needle, haystack)
{
	for (k = 0; k < haystack.length; k++)
	{
		if (needle === haystack[k])
		{
			haystack.splice(k, 1);
		}
	}
}

function time()
{
	return Math.round(new Date().getTime() / 1000);
}

window.onload = function() {
	inferno = new inferno();
	inferno.init();
}