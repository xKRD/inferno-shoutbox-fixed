<?php

/**
 * Inferno Shoutbox English Language Pack
 *  
 */

############ MAIN ############

// Main Shoutbox
$l['isb_shoutboxtab'] 		= 'Shoutbox';
$l['isb_activetab']   		= 'Active Users';
$l['isb_activeusers'] 		= 'Currently Active Shoutbox Users: {1}';

$l['isb_btn_shout'] 		= 'Shout';
$l['isb_btn_clear'] 		= 'Clear';
$l['isb_btn_smilies']		= 'Smilies';

// Archive
$l['isb_archive']			= 'Archive';
$l['isb_archive_dt']		= 'Archive Disabled';
$l['isb_archive_noview']	= 'You have no permission to view the archive.';
$l['isb_archive_disabled']	= 'The archive has been disabled by administrators.';
$l['isb_archive_page']		= 'Page';
$l['isb_archive_btn_go']	= 'Go';

// Auto-Messages
$l['isb_newthread']			= 'has posted a new thread: {1}';
$l['isb_newpost']			= 'has posted a new reply : {1}';
$l['isb_newpost_reach']			= 'has reached {1} posts';

############ SHOUTBOX COMMANDS ############ 

/*
	Each command is grouped with the message it displays (if applicable) when the command is executed
	
	Each command has the language prefix: isb_c_ 
	(stands for infernoshoutbox_command_)

	Example: 

	Changing

	$l['isb_c_me'] = 'me';

	TO

	$l['isb_c_me'] = 'mycommand';

	Will change the "/me" command syntax to "/mycommand".

*/

// Me
$l['isb_c_me']				= 'me';

// PM
$l['isb_c_pm']				= 'pm';

// Whisper
$l['isb_c_whisper']			= 'whisper';

// Notice
$l['isb_c_notice']			= 'notice';
$l['isb_c_notice_msg']		= 'Notice : {1}';
$l['isb_c_removenotice']	= 'removenotice';

// General terms
$l['isb_banned']			= 'Banned';
$l['isb_banned_sb']			= 'You are banned from the {1}.';
$l['isb_silenced']			= 'Silenced';

// Show lists
$l['isb_c_banlist']			= 'banlist';
$l['isb_c_silencelist']		= 'silencelist';
$l['isb_list']				= 'Currently {1} Users: {2}.';
$l['isb_list_empty']		= 'No users are currently {1}.';

// Ban
$l['isb_c_ban']				= 'ban';
$l['isb_c_unban']			= 'unban';
$l['isb_ban_msg']			= 'has banned {1} from the shoutbox!';
$l['isb_unban_msg']			= 'has unbanned {1} from the shoutbox!';
$l['isb_ban_msg_time_rea']  = 'has banned {1} from the shoutbox [Reason] {3} [days banned] {2} ';

//Full ban (Have to set user id, time in days and reason for the ban sepparated by ;)
$l['isb_c_ban_full']		= 'fullban';

// Silence	
$l['isb_c_silence']			= 'silence';
$l['isb_c_unsilence']		= 'unsilence';
$l['isb_silence_msg']		= 'has silenced {1} from the shoutbox!';
$l['isb_unsilence_msg']		= 'has unsilenced {1} from the shoutbox!';
	
// Prune	
$l['isb_c_prune']			= 'prune';
$l['isb_prune_msg']			= 'has pruned the shoutbox!';
$l['isb_prune_user_msg']	= 'has pruned all shouts by {1}!';
$l['isb_prune_days_msg']	= 'has pruned all shouts in the last {1} days!';

// Say	
$l['isb_c_say']				= 'say';

// Protected User
$l['isb_protected']			= 'User "{1}" is protected.';
// User doesn't exist
$l['isb_not_exists']		= 'User "{1}" does not exist.';
// User already banned
$l['isb_already_banned']	= 'User "{1}" is already banned.';

$l['isb_twitch_mode_cmd'] = "TwitchMode";
$l['isb_twitch_mode_votes'] = "TwitchModeVotes";
$l['isb_twitch_mode_enable_cmd'] = "TwitchModeOn";
$l['isb_twitch_mode_disable_cmd'] = "TwitchModeOff";
$l['isb_vote_ban_enable_cmd'] = "VoteBanOn";
$l['isb_vote_ban_disable_cmd'] = "VoteBanOff";
$l['isb_vote_ban_total_cmd'] = "VoteBanTotal";
$l['isb_vote_ban_cmd'] = "VoteBan";

## CHAT MESSAGES ##

$l['shout_pruned'] = "You have cleaned all the messages for the user with the ID: {1}";
$l['shout_cleaned'] = "You have cleaned the shoutbox";
$l['shout_deleted'] = "Delete messages by (User ID: {1}) (Message ID: {2})";
$l['shout_has'] = "Has ";
$l['shout_banned_user'] = "banned to the user with the ID: ";
$l['shout_have'] = "You have ";
$l['shout_have_silenced'] = "silence the user ID: "; 
$l['shout_installed1'] = 'Congratulations! Your copy of Inferno Shoutbox v {1} has installed successfully!';
$l['shout_installed2'] = 'Settings of this chate can be found into your Admin CP -> Configuration -> Inferno Shoutbox Options';
$l['shout_installed3'] = 'Command list of your chat can be changed into language files of inferno shoutbox';
$l['shout_installed4'] = 'To show archive clic on your chat title';
$l['shout_installed5'] = 'Clean all the chat writing /prune';
$l['shout_installed6'] = 'Double click in a message to delete it';
$l['shout_private_disabled'] = "Private messages are disabled.";
$l['isb_no_activeusers'] = "Actually there are no users online.";
$l['no_private_start'] = '<i>There are nothing ';
$l['no_private_text'] = 'privates';
$l['no_private_end'] = ' to show...</i>';

## JAVASCRIPT REFERENCES ##

$l['isb_cancel'] = "Cancel";
$l['isb_delete'] = "Delete";
$l['isb_update'] = "Update";
$l['isb_opt_error'] = "Something went wrong optimizing inferno shoutbox...";
$l['isb_reconect'] = 'Now you are logued off. Click <a href="javascript:void(0);" onclick="javascript: inferno.clear_idle(); return false;">here</a> to login.';
$l['isb_loading'] = "Loading...";
$l['isb_shout_error'] = "Message can not be loaded...";
$l['isb_shout_cleaned'] = "Chat cleaned successfully.";
$l['isb_shout_change_style'] = "Your style would change when you sent your message.";
$l['isb_shout_change_style_update'] = "Style properties updated.";
$l['isb_shout_wait1'] = "you must wait ";
$l['isb_shout_wait2'] = " second";
$l['isb_shout_wait3'] = "s";
$l['isb_shout_wait4'] = " to sent another message.";
$l['isb_shout_no_smilies'] = "There are no smilies to show.";
$l['isb_shout_smilies_error'] = "Smilies can not be loaded...";
$l['isb_shout_notice'] = '<b class="inferno_alert">Shout Notice:</b> ';
$l['isb_shout_send_error'] = 'You must write your message before sending.';
$l['isb_shout_send_error1'] = 'You have written ';
$l['isb_shout_send_error2'] = ' characters. Reduce your message.';
$l['isb_shout_error_loading'] = 'Chat can not be loaded this time, try again latter...';
$l['isb_shout_error_userlist'] = 'Active userlist can not be loaded...';
$l['isb_banned_list'] = 'Active Bans';
$l['isb_unban_error'] = 'You can not unban users...';
$l['isb_unban_user_error'] = 'The user you have selected for this request does not exist';
$l['isb_unban_success'] = 'The user {1} was unbaned from shoutbox';
$l['isb_modals_unknown'] = '<span>You must select a valid user</span>';
$l['isb_get_modals'] = '<span>{1} Total Shouts: {2}</span>';
$l['isb_unban_auto'] = 'Account unbanned automatic...<br>Reload Shoutbox to start use...<br>';
$l['isb_unban_expires_sin'] = 'Your period of ban expires today';
$l['isb_unban_expires_plu'] = 'Your period of ban expires on {1} days';
$l['isb_view_all'] = 'View all';
$l['isb_banned_users_list'] = 'Active Banned Lists ';
$l['isb_banned_totals'] = 'Total Banned'; 
$l['isb_banned_user'] = 'User';
$l['isb_banned_by'] = 'Banned By';
$l['isb_banned_reason'] = 'Reason';
$l['isb_banned_unban'] = 'Unban Date';
$l['isb_banned_moderator'] = 'Moderator';
$l['isb_some_moderator'] = 'Some Moderator';
$l['isb_unknow'] = 'Unknow';
$l['isb_never'] = 'Never';
$l['isb_unban_now'] = 'Unban Now';
$l['isb_unban_user_error'] = "<td colspan=\"5\"><span style=\"color:red;\">You can not unban users...</span></td>";
$l['isb_unban_user_error2'] = "<td colspan=\"5\"><span style=\"color:red;\">The user you have selected for this request does not exist</span></td>";
$l['isb_unban_user_success'] = "<td colspan=\"5\"><span style=\"color:green;\">The user {1} was unbaned from shoutbox</span></td>";
$l['isb_unban_user_automatic'] = "Account unbanned automatic...<br>Reload Shoutbox to start use...<br>";
$l['isb_unban_today'] = "today";
$l['isb_unban_days'] = "days";
$l['isb_unban_expires'] = "Your period of ban expires on...{1}";
$l['isb_invalid_user'] = "<span>You must select a valid user</span>";
$l['isb_user_banned'] = " is banned from the shoutbox...";
$l['isb_unban_expires_never'] = "You are banned from this shoutbox forever...";
$l['isb_link'] = "Link";
$l['isb_youtube'] = "Youtube";
$l['isb_title'] = "Title";
$l['isb_channel'] = "Channel";
$l['isb_time'] = "Time";
$l['isb_views'] = "Views";
$l['isb_likes'] = "Likes";
$l['isb_into_forums'] = " into the forum ";
$l['isb_my_profile'] = "My Profile";
$l['isb_user_profile'] = "User Profile";
$l['isb_private'] = "Private Messages";
$l['isb_send_private'] = "Send Private";
$l['isb_send_whisper'] = "Send Whisper";
$l['isb_whisper'] = "Whispers";
$l['isb_mention'] = "Mention User";
$l['isb_total_shouts'] = "Total Shouts: ";
$l['isb_close'] = "Close Modal";
$l['isb_twitch_mode'] = "Twitch Mode needs {1} votes to start";
$l['isb_twitch_mode_shout'] = "Twitch Mode is on, it needs {1} votes to start this mode.";
$l['isb_twitch_mode_error'] = "Total of votes needed to enter twich mode are {1}, you have to wait until next process, or disable Twich Mode and enable again to set a new value.";
$l['isb_twitch_mode_disabled'] = "Twitch Mode is disabled, you must enable to set a total of votes to start this mode.";
$l['isb_twitch_mode_usage'] = "Twitch Mode was enabled, now you can use /{1}[votes] (To set number of votes to start Twitch Mode)";
$l['isb_twitch_mode_enabled'] = "Twitch Mode is enabled...";
$l['isb_twitch_mode_enabled_error'] = "You can not turn on Twich Mode...";
$l['isb_twitch_mode_disabled_success'] = "Twitch Mode was disabled, all preferences must be removed.";
$l['isb_twitch_mode_disabled_error'] = "Twitch Mode is disabled...";
$l['isb_twitch_mode_disabled_error2'] = "You can not turn off Twich Mode...";
$l['isb_vote_ban_enabled'] = "Ban Mode is enabled";
$l['isb_vote_ban_enabled_error'] = "You can not turn off Ban Mode...";
$l['isb_vote_ban_disable'] = "Ban Mode was disabled, all preferences must be removed.";
$l['isb_vote_ban_disable_on'] = "Ban Mode is disabled";
$l['isb_vote_ban_disable_error'] = "You can not turn off Ban Mode...";
$l['isb_vote_ban_total'] = "Vote ban total is set to {1}";
$l['isb_vote_ban_total_msg'] = "Vote ban total is set to {1} votes to ban a user";
$l['isb_vote_ban_total_msg2'] = "Total of votes has been added with a total ammount of {1}, you have to wait until next process, or disable vote ban and enable again to set a new value.";
$l['isb_vote_ban_total_error'] = "Vote Ban is disabled, you must enable to set a total for ban a user.";
$l['isb_vote_ban_mode_enabled'] = "Ban Mode was Enabled, now you can use /VoteBanTotal [votes] To set number of votes to ban.";
$l['isb_vote_ban_user_error'] = "That user id does not exist into our database, verify and try again...";
$l['isb_vote_ban_total_admin_error'] = "Admin needs to set an ammount of total votes to ban a user, until you can add your votes.";
$l['isb_vote_ban_disabled'] = "Vote Ban is disabled";
$l['isb_twitch_mode_vote_added'] = "Vote added {1} votes more to start Twich Mode";
$l['isb_twitch_mode_vote_added_msg'] = "Twich mode requires {1} of {2} votes to start.";
$l['isb_twitch_mode_vote_started_msg'] = "Twich mode enabled and started with {1} of {2} total votes required.";
$l['isb_twitch_mode_vote_added_error'] = "You can only vote once per session of Twich Enabled function.";
$l['isb_twitch_mode_vote_added_error2'] = "You need to set a value of votes to start count the twich mode votes.";
$l['isb_twitch_mode_vote_added_error3'] = "Twich Mode is disabled, you must enable to set a total of votes to star this mode.";
$l['isb_twitch_mode_error2'] = "Twich Mode Disabled";
$l['isb_twitch_mode_error3'] = "Twich Mode was disabled...";
$l['isb_twitch_mode_success'] = "Twich Mode Enabled";
$l['isb_twitch_mode_success2'] = "Twich Mode was enabled, now you can use /TwitchmodeVotes 10 (To set to 10 the votes to start Twitch Mode)";
$l['isb_vote_ban_mode_error'] = "Vote Ban Mode Disabled";
$l['isb_vote_ban_mode_error2'] = "Vote Ban Mode was disabled...";
$l['isb_vote_ban_mode_success'] = "Vote Ban Mode Enabled";
$l['isb_vote_ban_mode_success_msg'] = "Use /vote_ban_total [total] Then users can use /vote_ban [uid]";
$l['isb_vote_ban_mode_success2'] = "Vote Ban Mode was enabled...";
$l['isb_admin_error'] = "You are not admin to use this function";
$l['isb_whispers_none'] = "There are no whispers to show";
$l['isb_whispers_to'] = "Whisper to {1}";
$l['isb_pm_to'] = "PM to {1}";
