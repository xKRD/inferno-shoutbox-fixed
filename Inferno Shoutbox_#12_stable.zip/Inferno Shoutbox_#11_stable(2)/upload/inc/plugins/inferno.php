<?php

if (!defined('IN_MYBB'))
{
	exit;
}

define('INFERNO_VERSION', '1.7.3');

$plugins->add_hook('global_intermediate', 'inferno_global');
$plugins->add_hook('global_start', 'inferno_modals');
$plugins->add_hook('admin_user_users_delete_commit', 'inferno_delete_user');
$plugins->add_hook('inferno_archive_start', 'inferno_archive');
$plugins->add_hook('newthread_do_newthread_end', 'inferno_newthread');
$plugins->add_hook('newreply_do_newreply_end', 'inferno_newpost');

function inferno_info()
{
	return array(
		'name'			=> 'Inferno Shoutbox',
		'description'	=> 'Inferno Shoutbox is a powerful shoutbox for your MyBB forum. (Created by Mattbox Solutions and Mantained by Whiteneo)',
		'website'		=> 'http://soportemybb.es',
		'author'		=> 'Whiteneo',
		'authorsite'	=> '',
		'version'		=> INFERNO_VERSION,
		'codename'		=> 'inferno_shoutbox',
		'compatibility' => '18*'
	);
}

function inferno_init()
{
	require_once MYBB_ROOT . 'inc/plugins/inferno/class_core.php';
	return inferno_shoutbox::get_instance();
}

function inferno_is_installed()
{
	$inferno = inferno_init();
	return $inferno->is_installed();
}

function inferno_install()
{
	$inferno = inferno_init();
	$inferno->install();
}

function inferno_activate()
{
	$inferno = inferno_init();
	$inferno->activate();
}

function inferno_deactivate()
{
	$inferno = inferno_init();
	$inferno->deactivate();
}

function inferno_uninstall()
{
	$inferno = inferno_init();
	$inferno->uninstall();
}

function inferno_global()
{
	global $mybb, $lang, $templates, $theme, $inferno_shoutbox, $inferno_container;

	if (defined('IN_MYBB') && IN_MYBB != 'infernoshout')
	{
		$inferno_container = "";
		if (isset($mybb->settings['inferno_enabled']) && $mybb->settings['inferno_enabled'] == 1)
		{
			$inferno = inferno_init();
			if($mybb->settings['inferno_usergroups_banned'] == -1 || $mybb->settings['inferno_usergroups_banned'] != '')
			{
				if(in_array($mybb->user['usergroup'], explode(',', $mybb->settings['inferno_usergroups_banned'])))
				{
					return false;
				}
				else if($mybb->settings['inferno_usergroups_banned'] == -1)
				{
					return false;
				}
			}
			if($mybb->settings['inferno_minimum_posts'] > 0)
			{
				if(!isset($mybb->user['postnum']) || (isset($mybb->user['postnum']) && $mybb->settings['inferno_minimum_posts'] > $mybb->user['postnum']))
				{
					return false;
				}
			}
			if (!$inferno->banned_usergroup)
			{
				$expaltext = $lang->expcol_expand;
				if($mybb->settings['inferno_shoutbox_postnum'] > 0)
				{
					if($mybb->usergroup['cancp'] == 1)
					{
						eval("\$inferno_container = \"".$templates->get("inferno_container", 1, 0)."\";");
					}
					else if($mybb->usergroup['cancp'] != 1 && (isset($mybb->user['postnum']) && $mybb->user['postnum'] >= $mybb->settings['inferno_shoutbox_postnum']))
					{
						eval("\$inferno_container = \"".$templates->get("inferno_container", 1, 0)."\";");
					}
				}
				else if($mybb->settings['inferno_shoutbox_postnum'] == 0)
				{
					eval("\$inferno_container = \"".$templates->get("inferno_container", 1, 0)."\";");
				}
				eval("\$inferno_shoutbox = \"".$templates->get("inferno_shoutbox", 1, 0)."\";");
				$inferno_shoutbox = $inferno->replace_template_vars($inferno_shoutbox);
			}
		}
	}
}

function inferno_archive()
{
	global $mybb, $templates, $theme, $settings, $inferno_archive_table, $lang;
	$lang->load('inferno',false,true);

	if ($settings['inferno_enabled'] && $settings['inferno_archive'])
	{
		$inferno = inferno_init();
		eval("\$inferno_archive_table = \"".$templates->get("inferno_archive_table", 1, 0)."\";");
		$inferno_archive_table = $inferno->replace_template_vars($inferno_archive_table);
	}
}

function inferno_newthread()
{
	global $mybb, $lang, $new_thread, $thread_info;

	if ($mybb->settings['inferno_enabled'])
	{
		$inferno = inferno_init();
		$tid = (int) $thread_info['tid'];
		$fid = (int) $new_thread['fid'];
		$forum_details = "";
		if($mybb->settings['inferno_shoutbox_detailed_info'] == 1)
		{
			$forum = get_forum($fid);
			$forum_subject = $forum['name'];
			$forum_link = "[url={$mybb->settings['bburl']}/".get_forum_link($fid)."]{$forum_subject}[/url]";
			$forum_details = $lang->isb_into_forums.$forum_link;	
		}
		if ($mybb->settings['inferno_thread_post'] && !in_array($fid, explode(',', $mybb->settings['inferno_thread_forums'])))
		{
			$link = '[url=' . $mybb->settings['bburl'] . '/' . get_thread_link($tid) . ']' . $new_thread['subject'] . '[/url]'.$forum_details;
			$shout = $lang->sprintf($lang->isb_newthread, $link);
			$inferno->create_shout($mybb->user['uid'], $shout, true);
		}
	}
}

function inferno_newpost()
{
	global $mybb, $lang, $post, $pid;
	$counter = (int) $mybb->settings['inferno_newpost'];
	$posts = (int) $mybb->user['postnum'] + 1;

	if ($mybb->settings['inferno_enabled'] && $counter)
	{
		$inferno = inferno_init();
		$tid = (int) $post['tid'];
		$fid = (int) $post['fid'];
		$forum_details = "";
		if($mybb->settings['inferno_shoutbox_detailed_info'] == 1)
		{
			$forum = get_forum($fid);
			$forum_subject = $forum['name'];
			$forum_link = "[url={$mybb->settings['bburl']}/".get_forum_link($fid)."]{$forum_subject}[/url]";
			$forum_details = $lang->isb_into_forums . $forum_link;
		}
		if ($mybb->settings['inferno_thread_post'] && !in_array($fid, explode(',', $mybb->settings['inferno_thread_forums'])))
		{
			$link = '[url=' . $mybb->settings['bburl'] . '/' . get_post_link($pid, $tid) . '#pid' . $pid .']' . $post['subject'] . '[/url]'.$forum_details;
			$shout = $lang->sprintf($lang->isb_newpost, $link);
			$inferno->create_shout($mybb->user['uid'], $shout, true);
		}
		if ($posts % $counter == 0)
		{
			$inferno->create_shout($mybb->user['uid'], $lang->sprintf($lang->isb_newpost_reach, $posts), true);
		}
	}
}

function inferno_delete_user()
{
	global $user;
	$inferno = inferno_init();
	$inferno->delete_user($user['uid']);
}

function inferno_modals()
{
	$inferno = inferno_init();
	$inferno->inferno_get_modals();
}

function inferno_mention_filter_callback($match)
{
	global $db, $mybb, $cache;
	static $name_cache;
	$name_parts = array();
	$shift_count = 0;
	$cache_changed = false;

	if(!isset($name_cache))
	{
		$name_cache = $cache->read('namecache');
	}

	array_shift($match);
	while(strlen(trim($match[0])) == 0 && !empty($match))
	{
		array_shift($match);
		++$shift_count;
	}

	// save the original name
	$orig_name = $match[0];
	$match[0] = trim(strtolower($match[0]));

	// if the name is already in the cache . . .
	if(isset($name_cache[$match[0]]))
	{
		$left_over = substr($orig_name, strlen($match[0]));
		return inferno_mention_build($name_cache[$match[0]]) . $left_over;
	}

	// if the array was shifted then no quotes were used
	if($shift_count)
	{
		// no padding necessary
		$shift_pad = 0;

		// split the string into an array of words
		$name_parts = explode(' ', $match[0]);

		// add the first part
		$username_lower = $name_parts[0];

		// if the name part we have is shorter than the minimum user name length (set in ACP) we need to loop through all the name parts and keep adding them until we at least reach the minimum length
		while(strlen($username_lower) < $mybb->settings['minnamelength'] && !empty($name_parts))
		{
			// discard the first part (we have it stored)
			array_shift($name_parts);
			if(strlen($name_parts[0]) == 0)
			{
				// no more parts?
				break;
			}

			// if there is another part add it
			$username_lower .= ' ' . $name_parts[0];
		}

		if(strlen($username_lower) < $mybb->settings['minnamelength'])
		{
			return $orig_name;
		}
	}
	else
	{
		// @ and two double quotes
		$shift_pad = 3;

		// grab the entire match
		$username_lower = $match[0];
	}

	// if the name is already in the cache . . .
	if(isset($name_cache[$username_lower]))
	{
		// . . . simply return it and save the query
		//  restore any surrounding characters from the original match
		return inferno_mention_build($name_cache[$username_lower]) . substr($orig_name, strlen($username_lower) + $shift_pad);
	}

	// lookup the user name
	$user = inferno_mention_try_name($username_lower);

	// if the user name exists . . .
	if(isset($user['uid']) && $user['uid'] != 0)
	{
		$cache_changed = true;

		// preserve any surrounding chars
		$left_over = substr($orig_name, strlen($user['username']) + $shift_pad);
	}
	// if no match and advanced matching is enabled . . .
	elseif($mybb->settings['inferno_mention_advanced_matching'])
	{
		// we've already checked the first part, discard it
		array_shift($name_parts);

		// if there are more parts and quotes weren't used
		if(empty($name_parts) || $shift_pad == 3 || strlen($name_parts[0]) <= 0)
		{
			// nothing else to try
			return "@{$orig_name}";
		}

		// start with the first part . . .
		$try_this = $username_lower;

		$all_good = false;

		// . . . loop through each part and try them in serial
		foreach($name_parts as $val)
		{
			// add the next part
			$try_this .= ' ' . $val;

			// check the cache for a match to save a query
			if(isset($name_cache[$try_this]))
			{
				// preserve any surrounding chars from the original match
				$left_over = substr($orig_name, strlen($try_this) + $shift_pad);
				return inferno_mention_build($name_cache[$try_this]) . $left_over;
			}

			// check the db
			$user = inferno_mention_try_name($try_this);

			// if there is a match . . .
			if((int) $user['uid'] == 0)
			{
				continue;
			}

			// cache the user name HTML
			$username_lower = strtolower($user['username']);

			// preserve any surrounding chars from the original match
			$left_over = substr($orig_name, strlen($user['username']) + $shift_pad);

			// and gtfo
			$all_good = true;
			$cache_changed = true;
			break;
		}

		if(!$all_good)
		{
			// still no matches?
			return "@{$orig_name}";
		}
	}
	else
	{
		// no match found and advanced matching is disabled
		return "@{$orig_name}";
	}

	// store the mention
	$name_cache[$username_lower] = $user;

	// if we had to query for this user's info then update the cache
	if($cache_changed)
	{
		$cache->update('namecache', $name_cache);
	}

	// and return the mention
	return inferno_mention_build($user) . $left_over;
}

function inferno_mention_build($user)
{
	if(!is_array($user) || empty($user) || strlen($user['username']) == 0)
	{
		return false;
	}

	$id = 0;
	$name = "inferno_mention_";
	$inferno_mention_function = "";
	$action = "";
	$evento = "";

	// set up the user name link so that it displays correctly for the display group of the user
	if (function_exists("avatarep_hover_extends"))
	{
		global $mybb;
		if(isset($mybb->settings['avatarep_menu']) && $mybb->settings['avatarep_menu'] == 1 && $mybb->settings['avatarep_menu_events'] == 2)
		{
			$id = (int)$user['uid'];
			$inferno_mention_function = avatarep_hover_extends($id, $name);
			$action = "?action=avatarep_popup";
			$evento = " onclick=\"return false;\"";				
		}
		else if(isset($mybb->settings['avatarep_menu']) && $mybb->settings['avatarep_menu'] == 1 && $mybb->settings['avatarep_menu_events'] == 1)
		{
			$evento = " onclick=\"MyBB.popupWindow('member.php?uid={$user['uid']}&amp;action=avatarep_popup', null, true); return false;\"";	
		}	
	}
	// the HTML id property is used to store the uid of the mentioned user for MyAlerts (if installed)
	$username = format_name(htmlspecialchars_uni($user['username']), $user['usergroup'], $user['displaygroup']);
	$url = get_profile_link($user['uid']);
	return <<<EOF
@<a id="inferno_mention_{$user['uid']}" class="inferno_mention_{$user['uid']}" href="{$url}{$action}"{$evento}>{$username}</a>{$inferno_mention_function}
EOF;
}

function inferno_mention_try_name($username = '')
{
	/**
	 * create another name cache here to save queries if names
	 * with spaces are used more than once in the same post
	 */
	static $name_list;

	if(!is_array($name_list))
	{
		$name_list = array();
	}

	$username = strtolower($username);

	// no user name supplied
	if(!$username)
	{
		return false;
	}

	// if the name is in this cache (has been searched for before)
	if(isset($name_list[$username]))
	{
		// . . . just return the data and save the query
		return $name_list[$username];
	}

	global $db;

	// query the db
	$query = $db->simple_select('users', 'uid, username, usergroup, displaygroup, additionalgroups', "LOWER(username)='{$db->escape_string($username)}'", array('limit' => 1));

	// result?
	if($db->num_rows($query) !== 1)
	{
		// no matches
		return false;
	}

	// cache the name
	$name_list[$username] = $db->fetch_array($query);

	// and return it
	return $name_list[$username];
}

function dvd($str)
{
	die(var_dump($str));
}