<?php

define('IN_MYBB', true);

require_once 'global.php';
require_once MYBB_ROOT . 'inc/plugins/inferno/class_core.php';
$inferno = inferno_shoutbox::get_instance();

$templatelist = "multipage_page_current, multipage_page, multipage_end, multipage_nextpage, multipage_jump_page, multipage,inferno_shoutbox,inferno_archive_table, inferno_archive,inferno_banned_list,inferno_banned_list_modal, inferno_modal_user, inferno_twitch_enabled, inferno_twitch_disabled, inferno_vote_ban_enabled, inferno_vote_ban_disabled";
$templatelist .= ", inferno_edit_buttons, inferno_edit_buttons_admin, inferno_chatbot_enabled, inferno_chatbot_disabled, inferno_pm_shout, inferno_whisper_shout, inferno_normal_shout_mine, inferno_normal_shout, inferno_delete_shout, inferno_pm_shout_mine, inferno_admin_commands, inferno_notice, inferno_whispers_remove, inferno_whispers_shout";

$allowed_actions = array(
	'getshouts',
	'newshout',
	'getactiveusers',
	'getsmilies',
	'updatestyles',
	'getprivateshouts',
	'getshout',
	'deleteshout',
	'removeshout',
	'updateshout',
	'getwhisper',
	'openanus',
	'archive',
	'getUserModals',
	'unbanUser',
	'ban_user',
	'inferno_banned_list',
	'disconect',
	'twich_mode',
	'vote_ban'
);

$action = (isset($_GET['action']) ? $_GET['action'] : false);

// Disallow failed get requests or if shoutbox is offline
if (!in_array($action, $allowed_actions) || !$settings['inferno_enabled'])
{
	exit;
}

$lang->load('inferno', false, true);
include_once(MYBB_ROOT . 'inc/plugins/inferno/config.php');

// Shorthand Userinfo
$uid 		= $inferno->userinfo['uid'];
$ugid 		= $mybb->user['usergroup'];
$bold 		= $inferno->userinfo['bold'];
$admin		= $inferno->admin;
$mod		= ($admin) ? true : $inferno->mod;
$italic		= $inferno->userinfo['italic'];
$underline 	= $inferno->userinfo['underline'];
$banned 	= $inferno->banned;
$silenced 	= $inferno->userinfo['silenced'];
$twich_mode = 0;
$vote_ban_total = 0;
$twich_mode_total = 0;
$twich_mode_count = 0;
$vote_ban = 0;
if(isset($inferno_config['twich_mode']))
$twich_mode = (int)$inferno_config['twich_mode'];
if(isset($inferno_config['vote_ban']))
$vote_ban	= (int)$inferno_config['vote_ban'];
if(isset($inferno_config['vote_ban_total']))
$vote_ban_total  = (int)$inferno_config['vote_ban_total'];
if(isset($inferno_config['twich_mode_total']))
$twich_mode_total = (int)$inferno_config['twich_mode_total'];
if(isset($inferno_config['twich_mode_count']))
$twich_mode_count = (int)$inferno_config['twich_mode_count'];

if ($action == 'openanus')
{
	echo (int) file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/anus.php');
}

if ($action == 'getshout')
{
	$id = (int) $_GET['id'];

	if ($id)
	{
		$shout = $inferno->get_shout($id);

		if ($shout)
		{
			if ($mod || $uid == $shout['uid'])
			{
				echo json_encode($shout);
			}
		}
	}
}

if ($action == 'updateshout')
{
	// CSRF Protection
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	
	$sid = (int) $mybb->input['sid'];
	$message = trim($mybb->input['shout']);

	if ($sid && $message)
	{
		$shout = $inferno->get_shout($sid);

		if ($shout)
		{
			if ($mod || $uid == $shout['uid'])
			{
				$inferno->update_shout($sid, $message);
			}
		}
	}
}

if ($action == 'deleteshout')
{
	// CSRF Protection
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	
	$sid = (int) $mybb->input['sid'];
	if ($sid)
	{
		$shout = $inferno->get_shout($sid);

		if ($shout)
		{
			if ($mod || $uid == $shout['uid'])
			{
				if(isset($mybb->cookies['inferno_cookie'][$uid]))
					my_unsetcookie("inferno_cookie[{$uid}]");
				$inferno->delete_shout($sid);
			}
		}
	}
}

if ($action == 'removeshout')
{
	// CSRF Protection - FIXED
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	
	$sid = (int)$mybb->input['sid'];
	$myuid = (int)$mybb->user['uid'];
	
	if ($sid)
	{
		// Get the shout to check ownership
		$shout = $inferno->get_shout($sid);
		
		if ($shout)
		{
			// Only allow deletion if user is moderator OR owns the shout
			if ($mod || $myuid == $shout['uid'])
			{
				if(isset($mybb->cookies['inferno_cookie'][$myuid]))
					my_unsetcookie("inferno_cookie[{$myuid}]");
				$inferno->remove_shout($sid);
			}
			else
			{
				// Unauthorized attempt
				exit;
			}
		}
	}
}

if ($action == 'ban_user')
{
	// CSRF Protection - FIXED
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	
	$uid = (int)$mybb->input['uid'];
	$myuid = (int)$mybb->user['uid'];
	if ($uid)
	{
		if ($mod)
		{
			$inferno->ban_user($uid);
		}
	}
}

if ($action == 'disconect')
{
	// CSRF Protection - FIXED
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	
	global $db, $mybb, $lang;
	$lang->load('inferno', false, true);
	$uid = (int)$mybb->user['uid'];
	if(!$uid)
	{
		echo $lang->isb_invalid_user;
		return false;
	}
	$uid = $db->escape_string($uid);
	$db->update_query("inferno_user",array("is_online" => 0),"uid=".$uid);
}

if ($action == 'getUserModals')
{
	global $db, $lang;
	$lang->load('inferno', false, true);
	$uid = (int) $mybb->input['uid'];
	$sid = (int) $mybb->input['sid'];	
	if(!$uid)
	{
		echo $lang->isb_invalid_user;
		return false;
	}
	$user = [];
	$row['modals'] = "";
	$row['sid'] = (int) $sid;
	if(!isset($mybb->cookies['inferno_cookie'][$uid]))
	{
		$user = $inferno->retrieve_user_shouts($uid);
		my_setcookie("inferno_cookie[{$uid}]", json_encode($user));
	}
	else
	{
		$user = json_decode($mybb->cookies['inferno_cookie'][$uid], true);
	}
	$row['uid'] = (int) $user['uid'];
	$user['username'] = htmlspecialchars_uni($user['username']);
	$user['username'] = format_name($user['username'], $user['usergroup'], $user['displaygroup']);
	$user['isb_total'] = my_number_format($user['Total']);
	eval("\$row['modals'] = \"".$templates->get("inferno_modal_user", 1, 0)."\";");
	echo $row['modals'];
	exit;
}

if ($action == 'getshouts')
{
	$pm = (isset($_GET['id'])) ? intval($_GET['id']) : 0;
	$shouts = $inferno->get_shouts($pm);
	$active_users = count($inferno->fetch_active_users());
	$admin_commands = "";
	$user = $inferno->get_user_data($mybb->user['uid']);

	if($admin)
	{
		if($twich_mode == 1)
			eval("\$tm_btn = \"".$templates->get("inferno_twitch_enabled", 1, 0)."\";");
		else
			eval("\$tm_btn = \"".$templates->get("inferno_twitch_disabled", 1, 0)."\";");		
		if($vote_ban == 1)
			eval("\$vb_btn = \"".$templates->get("inferno_vote_ban_enabled", 1, 0)."\";");
		else
			eval("\$vb_btn = \"".$templates->get("inferno_vote_ban_disabled", 1, 0)."\";");
		$admin_commands = '<div class="inferno_admin_buttons" style="float:right">' . $tm_btn . $vb_btn . '</div>';
	}

	$user['uid'] = (int)$user['uid'];
	$user['user'] = htmlspecialchars_uni($user['username']);
	$user['unread_pms'] = (int)$user['unread_pms'];
	$user['whispers'] = (int)$user['whispers'];

	if($user['unread_pms'] > 0)
		eval("\$admin_commands .= \"".$templates->get("inferno_unread_pms", 1, 0)."\";");
	if($user['whispers'] > 0)
		eval("\$admin_commands .= \"".$templates->get("inferno_unread_whispers", 1, 0)."\";");

	echo $active_users . $admin_commands. '<<~!PARSE_SHOUT!~>>';
		
	if ($banned)
	{
		echo $lang->sprintf($lang->isb_banned_sb, $settings['inferno_shoutbox_title']);
		verify_unban($mybb->user['uid']);
		exit;
	}
		
	if (!empty($settings['inferno_shoutbox_notice']))
	{
		$div = '<div class="inferno_notice" style="padding-top: 1px; padding-bottom: 1px;padding-bottom: 6px;">';
		echo $div . '<span class="inferno_notice">' . $inferno->render_notice() . '</span></div>';
	}

	if (empty($shouts))
	{
		echo $lang->no_private_start. (($pm) ? $lang->no_private_text : '') . $lang->no_private_end;
		exit;
	}

	if (!$pm)
	{
		foreach ($shouts as $s)
		{
			$string = '';
			$s['mark'] = '';
			eval("\$editor_buttons = \"".$templates->get("inferno_edit_buttons", 1, 0)."\";");
			eval("\$editor_buttons_mod = \"".$templates->get("inferno_edit_buttons_admin", 1, 0)."\";");
			if($s['is_read'] == 1)
				$s['mark'] = '<i class="fa fa-certificate" style="color:red">&nbsp;</i>';
			$avatars = "";
			if ($settings['inferno_avatars'])
			{
				$avatars .= $s['avatar'];
			}
			// Echo Me Shout
			if ($s['me'])
			{
				$chatbot = '';
				if ($uid == $s['uid'])
					$buttons = $editor_buttons;	
				else if($mod)
					$buttons = $editor_buttons_mod;						
				else
					$buttons = "";
				if(isset($mybb->settings['inferno_shoutbox_chatbot_enabled']) && $mybb->settings['inferno_shoutbox_chatbot_enabled'] == 1)
				{
					$chatbot = format_name('ChatBot',4,0);
					eval("\$string .= \"".$templates->get("inferno_chatbot_enabled", 1, 0)."\";");
				}
				else
					eval("\$string .= \"".$templates->get("inferno_chatbot_disabled", 1, 0)."\";");
				if ($mod || $uid == $s['uid'])
				{
					$string = $inferno->make_editable($string, $s['sid']);
				}

				echo $string;
			}
			// Private message
			else if ($s['private'] && $settings['inferno_shoutbox_pm'])
			{
				$to = '';

				if ($s['private'] !== $uid)
				{
					$pminfo = $inferno->fetch_mybb_userinfo($s['private']);
					$to = htmlspecialchars_uni($pminfo['username']);
					$private['to'] = $lang->sprintf($lang->isb_pm_to, $to);
				}
				else
				{
					$pminfo = $mybb->user;
					$to = htmlspecialchars_uni($pminfo['username']);
					$private['to'] = $lang->sprintf($lang->isb_pm_to, $to);
				}
				eval("\$string .= \"".$templates->get("inferno_pm_shout", 1, 0)."\";");
				if ($mod || $uid == $s['uid'])
				{
					$string = $inferno->make_editable($string, $s['sid']);
				}

				echo $string;
			}
			// Whispers
			else if ($s['whisper'])
			{
				$to = '';

				if ($s['whisper'] !== $uid)
				{
					$whisperinfo = $inferno->fetch_mybb_userinfo($s['whisper']);
					$to = htmlspecialchars_uni($whisperinfo['username']);
					$whisper['to'] = $lang->sprintf($lang->isb_whispers_to, $to);
				}
				else
				{
					$whisperinfo = $mybb->user;
					$to = htmlspecialchars_uni($whisperinfo['username']);
					$whisper['to'] = $lang->sprintf($lang->isb_whispers_to, $to);
				}
				eval("\$string .= \"".$templates->get("inferno_whisper_shout", 1, 0)."\";");

				if ($mod || $uid == $s['uid'])
				{
					$string = $inferno->make_editable($string, $s['sid']);
				}

				echo $string;
			}			
			// Echo Standard Shout
			else
			{
				if ($uid == $s['uid'])
					$buttons = $editor_buttons;	
				else if($mod)
					$buttons = $editor_buttons_mod;						
				else
					$buttons = "";	
				if($mybb->user['uid'] == $s['uid'])
					eval("\$string .= \"".$templates->get("inferno_normal_shout_mine", 1, 0)."\";");
				else
					eval("\$string .= \"".$templates->get("inferno_normal_shout", 1, 0)."\";");
				if ($mod || $uid == $s['uid'])
				{
					$string = $inferno->make_editable($string, $s['sid']);
				}
				echo $string;
			}
		}
	}
	else
	{
		if ($settings['inferno_shoutbox_pm'])
		{
			foreach ($shouts as $s)
			{
				eval("\$editor_buttons = \"".$templates->get("inferno_delete_shout", 1, 0)."\";");
				eval("\$string = \"".$templates->get("inferno_pm_shout_mine", 1, 0)."\";");

				if ($mod || $uid == $s['uid'])
				{
					$string = $inferno->make_editable($string, $s['sid']);
				}
				echo $string;
			}
		}
		else
		{
			echo $lang->shout_private_disabled;
		}
	}
}

if ($action == 'getwhisper')
{
	$whisper_id = (isset($_GET['uid'])) ? intval($_GET['uid']) : 0;
	$shouts = $inferno->get_whisper($whisper_id);
	$active_users = count($inferno->fetch_active_users());
	$admin_commands = "";
	$query = $db->simple_select('inferno_user','*','uid='.(int)$mybb->user['uid']);
	$user = $db->fetch_array($query);
	$user['uid'] = (int) $user['uid'];
	$user['username'] = htmlspecialchars_uni($user['username']);
	$user['username'] = $inferno->gen_profile_link($user['username'], $user['uid']);
	if($user['whispers'] > 0)
		eval("\$$admin_commands .= \"".$templates->get("inferno_admin_commands", 1, 0)."\";");
	echo $active_users .$admin_commands. '<<~!PARSE_SHOUT!~>><input type="hidden" name="whisperid" id="whisperid1" value="1">';

	if ($banned)
	{
		echo $lang->sprintf($lang->isb_banned_sb, $settings['inferno_shoutbox_title']);
		verify_unban($mybb->user['uid']);
		exit;
	}	
	if (!empty($settings['inferno_shoutbox_notice']))
	{
		$inferno_notice = $inferno->render_notice();
		eval("\$div = \"".$templates->get("inferno_notice", 1, 0)."\";");
		echo $div;
	}

	if (empty($shouts))
	{
		echo $lang->isb_whispers_none;
		exit;
	}
	
	foreach ($shouts as $s)
	{
		if($s['whisper'])
		{
			$string = '';
			eval("\$editor_buttons = \"".$templates->get("inferno_whispers_remove", 1, 0)."\";");	 
			if ($settings['inferno_avatars'])
			{
				$string .= $s['avatar'];
			}
			eval("\$string .= \"".$templates->get("inferno_whispers_shout", 1, 0)."\";");			
			echo $string;
		}
	}
}

function verify_unban ($uid)
{	
	global $db, $lang;
	$lang->load('inferno', false, true);
	$query = $db->simple_select("inferno_banned_users","*","ban_uid={$uid}");
	while($ban = $db->fetch_array($query))
	{
		$ban_start = $ban['ban_start'];
		$ban_end = $ban['ban_end'];	
	}	
	if($ban_end)
	{
		$time = time();
		if($time>$ban_end && $ban_end != -1)
		{
			$db->update_query("inferno_user",array("banned"=>0),"uid={$uid}");
			$db->delete_query("inferno_banned_users","ban_uid={$uid}");
			echo $lang->isb_unban_user_automatic;
		}		
		else if($ban_end>$time && $ban_end != -1)
		{
			$res = $ban_end - $time;
			$res = round($res / 60 / 60 / 24);
			if($res<=1)
				$res = $lang->isb_unban_today;
			else
				$res = $res . $lang->isb_unban_days;
			$lang->isb_unban_expires = $lang->sprintf($lang->isb_unban_expires, $res);
			echo $lang->isb_unban_expires;
		}
		else if($ban_end == -1)
			echo $lang->isb_unban_expires_never;
		else
			exit;
	}
}

if ($action == 'updatestyles')
{
	// CSRF Protection - FIXED
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	
	$allowed_colors = $inferno->get_setting_array('shoutbox_color');
	$allowed_fonts  = $inferno->get_setting_array('shoutbox_font');

	if (!isset($mybb->input['styles']) || $banned)
	{
		exit;
	}

	$styles = json_decode($mybb->input['styles'], true);

	$db_color		= in_array($styles['color'], $allowed_colors) ? $db->escape_string($styles['color']) : '';
	$db_font  		= in_array($styles['font'], $allowed_fonts)   ? $db->escape_string($styles['font'])  : '';
	$db_bold  		= ($styles['bold']) ? 1 : 0;
	$db_italic 		= ($styles['italic']) ? 1 : 0;
	$db_underline	= ($styles['underline']) ? 1 : 0;

	echo $db_color;

	$dbinfo = array(
		'bold'		=> $db_bold,
		'italic'	=> $db_italic,
		'underline'	=> $db_underline,
		'font'		=> $db_font,
		'color'		=> $db_color
	);

	$inferno->update_styles($dbinfo);
}

if ($action == 'getsmilies')
{
	$smilies = $inferno->get_smilies();
	echo $smilies;
}

if ($action == 'getactiveusers')
{
	$num = (isset($_GET['num'])) ? true : false;

	if ($banned)
	{
		echo $lang->sprintf($lang->isb_banned_sb, $settings['inferno_shoutbox_title']);
		exit;
	}

	$active_users = $inferno->fetch_active_users();

	if ($num)
	{
		echo count($active_users);
	}
	else
	{
		echo $lang->sprintf($lang->isb_activeusers, count($active_users)) . '<br />';
		echo (count($active_users) == 0) ? $lang->isb_no_activeusers : implode(', ', $active_users);
	}
}

if ($action == 'getbannedusers')
{
	$num = (isset($_GET['num'])) ? true : false;

	if ($banned)
	{
		echo $lang->sprintf($lang->isb_banned_sb, $settings['inferno_shoutbox_title']);
		exit;
	}

	$banned_users = $inferno->fetch_banned_users();

	if ($num)
	{
		echo count($banned_users);
	}
	else
	{
		echo $lang->sprintf($lang->isb_bannedusers, count($banned_users)) . '<br />';
		echo (count($banned_users) == 0) ? $lang->isb_no_bannedusers : implode(', ', $banned_users);
	}
}

if ($mybb->input['action'] == 'unbanUser')
{
	// CSRF Protection - FIXED
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	
	global $db, $lang;
	$lang->load('inferno', false, true);
	if(!$mod)
	{
		echo $lang->isb_unban_user_error;
		return false;
	}
	$uid = (int)$mybb->input['uid'];
	if(!$uid)
	{
		echo $lang->isb_unban_user_error2;
		return false;
	}
	$uid = $db->escape_string($uid);
	$db->update_query("inferno_user",array("banned"=>0),"banned=1 AND uid='".$uid."'",1);
	$db->delete_query("inferno_banned_users", "ban_uid='".$uid."'");
	$user = get_user($uid);
	$lang->isb_unban_user_success = $lang->sprintf($lang->isb_unban_user_success, htmlspecialchars_uni($user['username']));
	echo $lang->isb_unban_user_success;
}

if ($action == 'newshout')
{
	// CSRF Protection
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	$shout = trim($mybb->input['shout']);
	$styles = $mybb->input['styles'];
	if(isset($styles['bold']) && $styles['bold'] == 'true' && $mybb->settings['inferno_button_bold'] == 1)
	{
		$bold = '[b]{1}[/b]';
		$shout = str_replace('{1}', $shout, $bold);
	}
	if(isset($styles['italic']) && $styles['italic'] == 'true' && $mybb->settings['inferno_button_italic'] == 1)
	{
		$italic = '[i]{1}[/i]';
		$shout = str_replace('{1}', $shout, $italic);
	}
	if(isset($styles['underline']) && $styles['underline'] == 'true' && $mybb->settings['inferno_button_underline'] == 1)
	{
		$underline = '[u]{1}[/u]';
		$shout = str_replace('{1}', $shout, $underline);
	}
	if(isset($styles['color']) && $styles['color'] != '' && $mybb->settings['inferno_button_colors'] == 1)
	{
		$color = '[color='.$styles['color'].']{1}[/color]';
		$shout = str_replace('{1}', $shout, $color);
	}
	if(isset($styles['font']) && $styles['font'] != '' && $mybb->settings['inferno_button_fonts'] == 1)
	{
		$font = '[font='.$styles['font'].']{1}[/font]';
		$shout = str_replace('{1}', $shout, $font);
	}

	if(isset($mybb->cookies['inferno_cookie'][$mybb->user['uid']]))
		my_unsetcookie("inferno_cookie[{$mybb->user['uid']}]");

	$pmid = 0;
	$whisperid = 0;
	if(isset($mybb->input['pmid']))
	$pmid = (int) $mybb->input['pmid'];
	if(isset($mybb->input['whisperid']))
	$whisperid = (int )$mybb->input['whisperid'];
	$protected_groups = $inferno->get_setting_array('usergroups_protected', ',');

	$hide_admin = $settings['inferno_alert_admincommands'];

	if ($banned)
	{
		exit;
	}
	if($twich_mode == 0)
	{
		$inferno->control_flood();
	}
	else if($twich_mode == 1 && $twich_mode_total > 0)
	{
		if($twich_mode_total >= $twich_mode_count)
			$inferno->control_flood_none();
		else
			$inferno->control_flood();
	}
	if ($pmid)
	{
		if ($settings['inferno_shoutbox_pm'])
		{
			// Private message
			if (preg_match('/^\\/' . preg_quote($lang->isb_c_pm) . '[\s]+([^;]+);[\s]*(.+)$/', $shout, $matches) && $settings['inferno_shoutbox_pm'])
			{
				$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

				if ($mybb_user)
				{
					$inferno->create_shout($uid, $matches[2], false, $mybb_user['uid']);
				}
				else
				{
					$inferno->create_shout($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), false, $uid);
				}
				exit;
			}
			else
				$inferno->create_shout($uid, $shout, false, $pmid);
		}
		exit;
	}

	if ($whisperid)
	{
		// Whisper message
		if (preg_match('/^\\/' . preg_quote($lang->isb_c_whisper) . '[\s]+([^;]+);[\s]*(.+)$/', $shout, $matches))
		{
			$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

			if ($mybb_user)
			{
				$inferno->create_shout_whisper($uid, $matches[2], $mybb_user['uid']);
			}
			else
			{
				$inferno->create_shout_whisper($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), $uid);
			}
			exit;
		}		
		else
			$inferno->create_shout_whisper($uid, $shout, $whisperid);
		exit;
	}

	// Admin and mod commands
	if ($mod)
	{
		// Prune entire shoutbox
		if ($shout == '/' . $lang->isb_c_prune)
		{
			$inferno->prune();
			$inferno->create_shout($uid, $lang->isb_prune_msg, true);
			exit;
		}
		// Prune old shouts than x days
		if(preg_match('/^\\/' . preg_quote($lang->isb_c_prune) . '[\s]+(.*)$/', $shout, $matches))
		{
			$days = (int) $matches[1];
			if($days > 0)
			{
				$inferno->prune_days($days); 
				$inferno->create_shout($uid, $lang->sprintf($lang->isb_prune_days_msg, $days), true);
				exit;	
			}
		}
		// Prune a certain user
		else if (preg_match('/^\\/' . preg_quote($lang->isb_c_prune) . '[\s]+(.*)$/', $shout, $matches))
		{
			$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

			if ($mybb_user)
			{
				if (in_array($mybb_user['usergroup'], $protected_groups))
				{
					$inferno->create_shout($uid, $lang->sprintf($lang->isb_protected, $mybb_user['username']), false, $uid);
					exit;
				}

				$inferno->prune($mybb_user['uid']);

				if ($admin && $hide_admin)
				{
					exit;
				}

				$inferno->create_shout($uid, $lang->sprintf($lang->isb_prune_user_msg, $mybb_user['username']), true);
			}
			else
			{
				$inferno->create_shout($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), false, $uid);
			}
			exit;
		}

		// Set a notice
		if (preg_match('/^\\/' . preg_quote($lang->isb_c_notice) . '[\s]+(.*)$/', $shout, $matches))
		{
			$inferno->update_notice($matches[1]);
			exit;
		}

		// Remove a notice
		if ($shout == '/' . $lang->isb_c_removenotice)
		{
			$inferno->update_notice();
			exit;
		}

		// Fetch banlist
		if ($shout == '/' . $lang->isb_c_banlist)
		{
			$banlist = $inferno->gen_banlist();
			$inferno->create_shout($uid, $banlist, false, $uid);
			exit;
		}

		// Ban a certain user
		if (preg_match('/^\\/' . preg_quote($lang->isb_c_ban) . '[\s]+(.*)$/', $shout, $matches))
		{
			$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

			if ($mybb_user)
			{

				if (in_array($mybb_user['usergroup'], $protected_groups))
				{
					$inferno->create_shout($uid, $lang->sprintf($lang->isb_protected, $mybb_user['username']), false, $uid);
					exit;
				}

				$user = $inferno->fetch_userinfo($mybb_user['uid']);
		
				if (!$user['banned'])
				{
					$inferno->toggle_ban($user['uid'], true);

					if ($admin && $hide_admin)
					{
						exit;
					}

					$inferno->create_shout($uid, $lang->sprintf($lang->isb_ban_msg, $mybb_user['username']), true);
				}
				
				else
				{
					$inferno->create_shout($uid, $lang->sprintf($lang->isb_already_banned, $mybb_user['username']), false, $uid);
					exit;
				}				
			}
			else
			{
				$inferno->create_shout($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), false, $uid);
				exit;
			}
			exit;
		}

		// Ban a certain user by time and reason
		if (preg_match('/^\\/' . preg_quote($lang->isb_c_ban_full) . '[\s]+([^;]+);+([^;]+);[\s]*(.+)$/', $shout, $matches))
		{
			$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

			if ($mybb_user)
			{

				if (in_array($mybb_user['usergroup'], $protected_groups))
				{
					$inferno->create_shout($uid, $lang->sprintf($lang->isb_protected, $mybb_user['username']), false, $uid);
					exit;
				}

				$user = $inferno->fetch_userinfo($mybb_user['uid']);

				if (!$user['banned'])
				{
					$inferno->toggle_ban_time($user['uid'], $matches[2], $matches[3], true);

					if ($admin && $hide_admin)
					{
						exit;
					}

					$inferno->create_shout($uid, $lang->sprintf($lang->isb_ban_msg_time_rea, $mybb_user['username'], $matches[2], $matches[3]), true);
					exit;
				}
				
				else
				{
					$inferno->create_shout($uid, $lang->sprintf($lang->isb_already_banned, $mybb_user['username']), false, $uid);
					exit;
				}				
			}
			else
			{
				$inferno->create_shout($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), false, $uid);
				exit;				
			}
			exit;
		}
		
		// Unban a certain user
		if (preg_match('/^\\/' . preg_quote($lang->isb_c_unban) . '[\s]+(.*)$/', $shout, $matches))
		{
			$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

			if ($mybb_user)
			{

				if (in_array($mybb_user['usergroup'], $protected_groups))
				{
					$inferno->create_shout($uid, $lang->sprintf($lang->isb_protected, $mybb_user['username']), false, $uid);
					exit;
				}

				$user = $inferno->fetch_userinfo($mybb_user['uid']);
				
				if ($user['banned'])
				{
					$inferno->toggle_ban($user['uid'], false);

					if ($admin && $hide_admin)
					{
						exit;
					}

					$inferno->create_shout($uid, $lang->sprintf($lang->isb_unban_msg, $mybb_user['username']), true);
					exit;
				}				
			}
			else
			{
				$inferno->create_shout($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), false, $uid);
				exit;
			}
			exit;
		}

		// Fetch silencelist
		if ($shout == '/' . $lang->isb_c_silencelist)
		{
			$silencelist = $inferno->gen_silencelist();
			$inferno->create_shout($uid, $silencelist, false, $uid);
			exit;
		}

		// Silence a certain user
		if (preg_match('/^\\/' . preg_quote($lang->isb_c_silence) . '[\s]+(.*)$/', $shout, $matches))
		{
			$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

			if ($mybb_user)
			{

				if (in_array($mybb_user['usergroup'], $protected_groups))
				{
					$inferno->create_shout($uid, $lang->sprintf($lang->isb_protected, $mybb_user['username']), false, $uid);
					exit;
				}

				$user = $inferno->fetch_userinfo($mybb_user['uid']);

				if (!$user['silenced'])
				{
					$inferno->toggle_silence($user['uid'], true);

					if ($admin && $hide_admin)
					{
						exit;
					}

					$inferno->create_shout($uid, $lang->sprintf($lang->isb_silence_msg, $mybb_user['username']), true);
					exit;
				}
			}
			else
			{
				$inferno->create_shout($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), false, $uid);
				exit;
			}
			exit;
		}

		// Unsilence a certain user
		if (preg_match('/^\\/' . preg_quote($lang->isb_c_unsilence) . '[\s]+(.*)$/', $shout, $matches))
		{
			$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

			if ($mybb_user)
			{

				if (in_array($mybb_user['usergroup'], $protected_groups))
				{
					$inferno->create_shout($uid, $lang->sprintf($lang->isb_protected, $mybb_user['username']), false, $uid);
					exit;
				}

				$user = $inferno->fetch_userinfo($mybb_user['uid']);

				if ($user['silenced'])
				{
					$inferno->toggle_silence($user['uid'], false);

					if ($admin && $hide_admin)
					{
						exit;
					}

					$inferno->create_shout($uid, $lang->sprintf($lang->isb_unsilence_msg, $mybb_user['username']), true);
					exit;
				}
			}
			else
			{
				$inferno->create_shout($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), false, $uid);
				exit;
			}
			exit;
		}
	}

	// Admin only commands
	if ($admin)
	{	
		if (preg_match('/^\\/' . preg_quote($lang->isb_c_say) . '[\s]+([^;]+);[\s]*(.+)$/', $shout, $matches))
		{
			$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

			if ($mybb_user)
			{
				$inferno->create_shout($mybb_user['uid'], $matches[2]);
				exit;
			}
			else
			{
				$inferno->create_shout($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), false, $uid);
				exit;
			}
			exit;
		}

		// Twich Mode set totals.
		if (preg_match('/^\\/' . preg_quote($lang->isb_twitch_mode_votes) . '[\s]+(.*)$/', $shout, $matches))
		{
			if($twich_mode == 1 && $twich_mode_total == 0)
			{
				$total = (int)$matches[1];
				if ($total)
				{
					update_config($mybb->user['uid'],$twich_mode,$total,$twich_mode_count,$vote_ban,$vote_ban_total);
					$lang->isb_twitch_mode = $lang->sprintf($lang->isb_twitch_mode, (int)$total);
					echo $lang->isb_twitch_mode;
					$lang->isb_twitch_mode_shout = $lang->sprintf($lang->isb_twitch_mode_shout, (int)$total);
					$inferno->create_shout($uid, $lang->isb_twitch_mode_shout, true);
					exit;
				}
			}
			else if($twich_mode_total > 0)
			{
				$lang->isb_twitch_mode_error = $lang->sprintf($lang->isb_twitch_mode_error, (int)$twich_mode_total);
				echo $lang->isb_twitch_mode_error;
				exit;			
			}
			else
			{
				echo $lang->isb_twitch_mode_disabled;
				exit;
			}
		}

		if ($shout == '/'.$lang->isb_twitch_mode_enable_cmd)
		{
			$uid = (int)$mybb->user['uid'];
			if ($uid && $twich_mode == 0)
			{
				update_config($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
				$lang->isb_twitch_mode_usage = $lang->sprintf($lang->isb_twitch_mode_usage, $lang->isb_twitch_mode_votes);
				echo $lang->isb_twitch_mode_usage;
				exit;
			}
			else if($twich_mode == 1)
			{
				echo $lang->isb_twitch_mode_enabled;
				exit;
			}				
			else	
			{
				echo $lang->isb_twitch_mode_enabled_error;
				exit;
			}
			exit;
		}

		if ($shout == '/'.$lang->isb_twitch_mode_disable_cmd)
		{
			$uid = (int)$mybb->user['uid'];
			if ($uid && $twich_mode == 1)
			{
				update_config($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
				//disable_twich_mode($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
				echo $lang->isb_twitch_mode_disabled_success;
				exit;
			}
			else if($twich_mode == 0)
			{
				echo $lang->isb_twitch_mode_disabled_error;
				exit;
			}				
			else
			{
				echo $lang->isb_twitch_mode_disabled_error2;
				exit;
			}
			exit;
		}
		
		if($shout == '/'.$lang->isb_vote_ban_enable_cmd)
		{
			$uid = (int)$mybb->user['uid'];
			if ($uid && $vote_ban == 0)
			{
				update_config($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
				//enable_ban_mode($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
				echo $lang->isb_vote_ban_total_error;
				exit;
			}
			else if($vote_ban == 1)
			{
				echo $lang->isb_vote_ban_enabled;
				exit;
			}
			else
			{
				echo $lang->isb_vote_ban_enabled_error;
				exit;
			}
			exit;
		}

		if($shout == '/'.$lang->isb_vote_ban_disable_cmd)
		{
			$uid = (int)$mybb->user['uid'];
			if ($uid && $vote_ban == 1)
			{
				update_config($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
				//disable_ban_mode($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
				echo $lang->isb_vote_ban_disable;
				exit;
			}
			else if($vote_ban == 1)
			{
				echo $lang->isb_vote_ban_disable_on;
				exit;
			}	
			else
			{
				echo $lang->isb_vote_ban_disable_error;
				exit;
			}
			exit;
		}

		// Vote for bans set totals
		if (preg_match('/^\\/' . preg_quote($lang->isb_vote_ban_total_cmd) . '[\s]+(.*)$/', $shout, $matches))
		{
			if($vote_ban == 1 && $vote_ban_total == 0)
			{
				$total = (int)$matches[1];
				if ($total)
				{
					update_config($mybb->user['uid'],$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$total);
					//update_config($twich_mode, $vote_ban, $total);
					$lang->isb_vote_ban_total = $lang->sprintf($lang->isb_vote_ban_total, (int)$total);
					echo $lang->isb_vote_ban_total;
					$lang->isb_vote_ban_total_msg = $lang->sprintf($lang->isb_vote_ban_total_msg, (int)$total);
					$inferno->create_shout($uid, $lang->isb_vote_ban_total_msg, true);
					exit;
				}
			}
			else if($vote_ban_total > 0)
			{
				$lang->isb_vote_ban_total_msg2 = $lang->sprintf($lang->isb_vote_ban_total_msg2, (int)$vote_ban_total);
				echo $lang->isb_vote_ban_total_msg2;
				exit;			
			}
			else
			{
				echo $lang->isb_vote_ban_total_error;
				exit;
			}
		}

		if($shout == '/CommandList' || $shout == '/help')
		{
			$uid = (int)$mybb->user['uid'];
			if ($uid)
			{
				$inferno->create_shout($uid, "USER COMMANDS
------------------------
/me;Message
/pm [uid];Message
/whisper [uid];Message
/VoteBan [uid]
", true);
$inferno->create_shout($uid, "MOD COMMANDS
------------------------
/notice;Message
/removenotice
/banlist
/silencelist
/ban [uid]
/unban [uid]
/fullban [uid]
/silence [uid]
/unsilence [uid]
", true);
$inferno->create_shout($uid, "ADMIN COMMANDS
------------------------
/TwitchMode
/VoteBanTotal [votes]
/VoteBanOn
/VoteBanOff
/TwitchModeOn
/TwitchModeOff
/TwitchModeVotes [votes]
/prune
/prune [days]
/say [uid];Message", true);			
			exit;
			}
		}
		// if ($shout == '/debug')
		// {
		// 	for ($i = 0; $i < 1000; $i++)
		// 	{
		// 		$inferno->create_shout($uid, $i + 1);
		// 	}
		// 	exit;
		// }
	}

	// Me message
	if (preg_match('/^\\/' . preg_quote($lang->isb_c_me) . '[\s]+(.*)$/', $shout, $matches))
	{
		$inferno->create_shout($uid, $matches[1], true);
		exit;
	}

	// Vote for bans.
	if (preg_match('/^\\/' . preg_quote($lang->isb_vote_ban_cmd) . '[\s]+(.*)$/', $shout, $matches))
	{
		if($vote_ban == 1 && $vote_ban_total > 0)
		{
			$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);
			if ($mybb_user)
			{
				$uid = (int)$mybb->user['uid'];
				$touid = (int)$mybb_user['uid'];
				$inferno->vote_ban($uid, $touid);
				exit;
			}
			else
			{
				echo $lang->isb_vote_ban_user_error;
				exit;
			}
		}
		else if($vote_ban == 1 && $vote_ban_total == 0)
		{
			echo $lang->isb_vote_ban_user_error;
			exit;
		}
		else
		{
			echo $lang->isb_vote_ban_disabled;
			exit;
		}
	}

	// Vote for Twich Mode.
	if ($shout == '/'.$lang->isb_twitch_mode_cmd)
	{
		$twich_mode_total = (int)$twich_mode_total;		
		$twich_mode_count =	(int)$twich_mode_count;
		if($twich_mode == 1 && $twich_mode_total > 0)
		{
			if ($twich_mode_total > 0)
			{
				$uid = $mybb->user['uid'];
				if($inferno->verify_can_vote($uid) == true)
				{
					$twich_mode_count++;
					$required = $twich_mode_total - $twich_mode_count;
					if($required < $twich_mode_total)
					{
						update_config($mybb->user['uid'],$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
						$lang->isb_twitch_mode_vote_added = $lang->sprintf($lang->isb_twitch_mode_vote_added, (int)$required);
						echo $lang->isb_twitch_mode_vote_added;
						$lang->isb_twitch_mode_vote_added_msg = $lang->sprintf($lang->isb_twitch_mode_vote_added_msg, (int)$record, (int)$total);
						$inferno->create_shout($uid, $lang->isb_twitch_mode_vote_added_msg, true);
						exit;
					}
					else
					{
						$lang->isb_twitch_mode_vote_started_msg = $lang->sprintf($lang->isb_twitch_mode_vote_started_msg, (int)$record, (int)$total);
						$inferno->create_shout($uid, $lang->isb_twitch_mode_vote_started_msg, true);
						$inferno->update_twich_counters();
						exit;
					}
				}
				else
				{
					echo $lang->isb_twitch_mode_vote_added_error;
					exit;					
				}				
			}
		}
		else if($twich_mode_total == 0)
		{
			echo $lang->isb_twitch_mode_vote_added_error2;
			exit;			
		}
		else
		{
			echo $lang->isb_twitch_mode_vote_added_error3;
			exit;
		}
	}

	// Whisper message
	if (preg_match('/^\\/' . preg_quote($lang->isb_c_whisper) . '[\s]+([^;]+);[\s]*(.+)$/', $shout, $matches))
	{
		$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

		if ($mybb_user)
		{
			$inferno->create_shout_whisper($uid, $matches[2], $mybb_user['uid']);
			exit;
		}
		else
		{
			$inferno->create_shout_whisper($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), $uid);
			exit;
		}
		exit;
	}
	
	// Private message
	if (preg_match('/^\\/' . preg_quote($lang->isb_c_pm) . '[\s]+([^;]+);[\s]*(.+)$/', $shout, $matches) && $settings['inferno_shoutbox_pm'])
	{
		$mybb_user = $inferno->fetch_mybb_userinfo($matches[1]);

		if ($mybb_user)
		{
			$inferno->create_shout($uid, $matches[2], false, $mybb_user['uid']);
			exit;
		}
		else
		{
			$inferno->create_shout($uid, $lang->sprintf($lang->isb_not_exists, $matches[1]), false, $uid);
			exit;
		}
	}

	$inferno->create_shout($uid, $shout);
}

if ($action == 'archive')
{
	add_breadcrumb($settings['inferno_shoutbox_title'] . ' ' . $lang->isb_archive, 'infernoshout.php?action=archive');

	if (!$settings['inferno_archive'] || $banned)
	{
		$title = $settings['inferno_shoutbox_title'] . $lang->isb_archive_dt;
		$error = $lang->isb_archive_disabled;
		if ($banned)
		{
			$error = $lang->isb_archive_noview;
		}
		eval("\$archive = \"".$templates->get("error", 1, 0)."\";");
	}
	else
	{
		$total_pages = $inferno->count_total_shouts();
		$shouts_per_page = $settings['inferno_archive_shouts_per_page'];
		$shouts_per_page = ($shouts_per_page > 0 && $shouts_per_page <= $total_pages) ? $shouts_per_page : 50;
		$page = (isset($_GET['page']) ? (int) round($_GET['page']) : 1);
		$page = ($page > 0 && $page <= $total_pages) ? $page : 1;
		$total_pages = ceil($inferno->count_total_shouts() / $shouts_per_page);
		$offset = ($page <= 1 || $page > $total_pages) ? 0 : ($page - 1) * $shouts_per_page;
		$plugins->run_hooks('inferno_archive_start');
		eval("\$archive = \"".$templates->get("inferno_archive", 1, 0)."\";");
	}

	output_page($archive);
}

if ($action == 'inferno_banned_list')
{
	add_breadcrumb($settings['inferno_shoutbox_title'] . ' ' . $lang->isb_banned_users_list, 'infernoshout.php?action=inferno_banned_list');
	$ban_list = $inferno->get_banned_list();
	output_page($ban_list);
}

if ($action == 'twich_mode')
{
	// CSRF Protection - FIXED
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	
	if($admin)
	{
		if(!$uid)
			$uid = (int)$mybb->user['uid'];		
		if($twich_mode == 1)
		{
			$twich_mode = 0;
			echo "<s>".$lang->isb_twitch_mode_error2."</s>";
			$inferno->create_shout($uid, $lang->isb_twitch_mode_error3, true);
		}
		else
		{
			$twich_mode = 1;
			echo "<b>".$lang->isb_twitch_mode_success."</b>";
			$inferno->create_shout($uid, $lang->isb_twitch_mode_success2, true);
		}
		update_config($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
	}
	else
	{	
		echo "Error 201";
		exit;
	}	
}

if ($action == 'vote_ban')
{
	// CSRF Protection - FIXED
	$post_key = $mybb->get_input('my_post_key', MyBB::INPUT_STRING);
	verify_post_check($post_key);
	
	if($admin)
	{
		if(!$uid)
			$uid = (int)$mybb->user['uid'];
		if($vote_ban == 1)
		{
			$vote_ban = 0;
			echo "<s>".$lang->isb_vote_ban_mode_error."</s>";
			$inferno->create_shout($uid, $lang->isb_vote_ban_mode_error2, true);
		}
		else
		{
			$vote_ban = 1;
			echo "<b>".$lang->isb_vote_ban_mode_success."</b> ".$lang->isb_vote_ban_mode_success_msg;
			$inferno->create_shout($uid, $lang->isb_vote_ban_mode_success2, true);
		}
		update_config($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total);
	}
	else
	{
		echo "Error 202";
		exit;
	}
}

function update_config($uid,$twich_mode,$twich_mode_total,$twich_mode_count,$vote_ban,$vote_ban_total)
{
	global $lang;
	$user = get_user($uid);
	if(!$user['usergroup'] == 4)
	{
		echo $lang->isb_admin_error;
		return false;
	}
	$fp = fopen(MYBB_ROOT . 'inc/plugins/inferno/config.php', 'w');
	$data = "<?php
\$inferno_config = array(
	'twich_mode' => ".$twich_mode.",
	'twich_mode_total' => ".$twich_mode_total.",
	'twich_mode_count' => ".$twich_mode_count.",	
	'vote_ban' => ".$vote_ban.",
	'vote_ban_total' => ".$vote_ban_total."
);";
	fwrite($fp, $data);
	return fclose($fp);
}