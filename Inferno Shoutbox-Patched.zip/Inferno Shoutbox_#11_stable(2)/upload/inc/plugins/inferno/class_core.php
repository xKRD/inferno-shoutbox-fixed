<?php

/**
 * Inferno Shoutbox Class
 * Project Started: 12/16/2013
 *
 * @author Mattbox Solutions
 */
class inferno_shoutbox
{
	public static $_instance = null;
	public $mybb;
	public $db;
	public $lang;
	public $settings;
	public $userinfo;
	public $templates;
	public $admin = false;
	public $mod = false;
	public $banned = true;
	public $banned_usergroup = true;
	public $anus = false;
	public $version = INFERNO_VERSION;
	public $debug = false;

	/**
	 * Constructor Method
	 *
	 * @return void
	 */
	private function __construct()
	{
		global $mybb, $db, $settings, $footer, $lang, $templates;

		$this->mybb 	 =& $mybb;
		$this->db 		 =& $db;
		$this->settings  =& $settings;
		$this->lang 	 =& $lang;
		$this->templates =& $templates;

		if ($this->is_installed())
		{
			$this->userinfo = $this->fetch_userinfo();
			$this->admin = $this->get_permissions('admin');
			$this->mod = $this->get_permissions('mod');
			$this->banned = $this->is_banned();
			$this->banned_usergroup = $this->is_banned(true);
			$this->anus = isset($this->settings['inferno_shoutbox_anus']) ? (bool) $this->settings['inferno_shoutbox_anus'] : false;
			$this->please_support_the_developer($footer);
		}
	}

	/**
	 * Inferno Instance Method
	 *
	 * @return object
	 */
	public static function get_instance()
	{
		if (!isset(self::$_instance))
		{
			self::$_instance = new inferno_shoutbox();
		}
		return self::$_instance;
	}

	public function is_banned($usergroup = false)
	{
		if(isset($this->mybb->settings['inferno_usergroups_banned']) && $this->mybb->settings['inferno_usergroups_banned'] == - 1)
		{
			return false;
		}
		else if(isset($this->mybb->settings['inferno_usergroups_banned']) && $this->mybb->settings['inferno_usergroups_banned'] == "")
		{
			return true;
		}
		else
		{
			$banned_groups = $this->get_setting_array('usergroups_banned', ',');

			if (!$usergroup)
			{
				return (isset($this->userinfo['banned']) ? $this->userinfo['banned'] : '' || in_array($this->mybb->user['usergroup'], $banned_groups));
			}
			else
			{
				return (is_array($this->mybb->user['usergroup']) && in_array($this->mybb->user['usergroup'], $banned_groups));
			}
		}
		$posts = (int) $this->mybb->settings['inferno_minimum_posts'];
		if ($posts && $this->mybb->user['postnum'] < $posts)
		{
		 	return true;
		}
	}

	public function inferno_get_modals()
	{
		global $db, $mybb, $lang, $theme, $templates, $isb_banned_list, $isb_banned_list_rows, $templatelist;
		
		if(isset($templatelist))
		{
			$templatelist .= ",multipage_page_current, multipage_page, multipage_end, multipage_nextpage, multipage_jump_page, multipage,inferno_shoutbox, inferno_container, inferno_archive_table, inferno_archive, inferno_banned_list_modal, inferno_banned_list";
		}
		$lang->load('inferno', false, true);
		$isb_banned_list = '';
		$isb_banned_list_rows = '';
		if(isset($mybb->input['action']) && $mybb->input['action'] == 'isb_ban_list')
		{		
			$query = $db->query("
				SELECT iu.uid, iu.banned, ibu.*, u.username as ban_username, u.usergroup as ban_usergroup, u.displaygroup as ban_displaygroup, um.username as banby_username, um.usergroup as banby_usergroup, um.displaygroup as banby_displaygroup
					FROM " . TABLE_PREFIX . "inferno_user iu
				LEFT JOIN " . TABLE_PREFIX . "inferno_banned_users ibu
					ON (iu.uid = ibu.ban_uid)
				LEFT JOIN " . TABLE_PREFIX . "users u
					ON (iu.uid = u.uid)
				LEFT JOIN " . TABLE_PREFIX . "users um
					ON (ibu.ban_by = um.uid)
				WHERE iu.banned=1
					ORDER BY ban_end ASC			
				LIMIT 10
			");

			while ($row = $db->fetch_array($query))
			{
				$ban_user = htmlspecialchars_uni($row['ban_username']);
				$ban_user = format_name($row['ban_username'], $row['ban_usergroup'], $row['ban_displaygroup']);
				$ban_user = build_profile_link($ban_user, $row['ban_uid']);		
				if(!empty($row['banby_username']))
				{
					$ban_by = htmlspecialchars_uni($row['banby_username']);
					$ban_by = format_name($row['banby_username'], $row['banby_usergroup'], $row['banby_displaygroup']);
					$ban_by = build_profile_link($ban_by, $row['ban_by']);
					$reason = $row['ban_reason'];
					if($row['ban_end'] == -1)
						$unban = $lang->isb_never;
					else
						$unban = my_date($mybb->settings['dateformat'], $row['ban_end']);				
				}
				else
				{
					$ban_by = $lang->isb_some_moderator;
					$reason = $lang->isb_unknow;				
				}
				eval("\$isb_banned_list_rows .= \"".$this->templates->get("inferno_banned_list_modal_rows", 1, 0)."\";");			
			}		

			eval("\$isb_banned_list = \"".$this->templates->get("inferno_banned_list_modal", 1, 0)."\";");
			echo $isb_banned_list;
			exit;
		}
	}

	public function is_valid_shout($shout)
	{
		$shout = trim($shout);
		if (strlen($shout) > 0 && strlen($shout) < $this->settings['inferno_shout_max_chars'])
		{
			return true;
		}
		return false;
	}

	public function update_anus()
	{
		if ($this->anus)
		{
			$fp = fopen(MYBB_ROOT . 'inc/plugins/inferno/anus.php', 'w');
			fwrite($fp, TIME_NOW);
			return fclose($fp);
		}
		return false;
	}
	
	public function clean_shout($shout)
	{
		$shout = $this->db->escape_string($shout);
		return $shout;
	}

	public function set_activity()
	{
		return my_setcookie('inferno_wait', (TIME_NOW + $this->settings['inferno_shoutbox_flood'])); 	
	}

	public function control_flood()
	{
		$now = TIME_NOW;
		$wait = $this->mybb->cookies['inferno_wait'];

		if ($now < $wait)
		{
			$time = $wait - $now;
			echo "Your must wait {$time} more secs to do this.";
			exit;
		}
		else
		{
			$this->set_activity();
		}
	}
	
	public function set_activity_none()
	{
		return my_setcookie('inferno_wait', (TIME_NOW));
	}
	
	public function control_flood_none()
	{
		$this->set_activity_none();		
	}

	public function vote_ban($uid, $touid)
	{
		global $inferno_config;
		require_once(MYBB_ROOT . 'inc/plugins/inferno/config.php');
		$twich_mode = (int)$inferno_config['twich_mode'];
		$vote_ban = (int)$inferno_config['vote_ban'];
		$total = (int)$inferno_config['vote_ban_total'];
		if($vote_ban == 0)
		{
			echo "Vote ban mode is disabled";
			exit;
		}
		else if($vote_ban == 1 && $total > 0)
		{
			$verify_can_vote = $this->db->simple_select('inferno_user','ban_votes_add','ban_votes_add=1 AND uid='.(int)$uid);
			if($this->db->num_rows($verify_can_vote) == 0)
			{
				$data = $this->db->simple_select('inferno_user','ban_votes','uid='.(int)$touid);
				if($this->db->num_rows($data) > 0)
				{
					$record = $this->db->fetch_field($data, 'ban_votes');
					$user =	get_user($touid);
					$username = htmlspecialchars_uni($user['username']);
					$record = (int)$record + 1;
					if($record >= $total)
					{
						$this->ban_user($touid);
						$this->update_config($twich_mode, 0, 0);
						$this->update_ban_totals();
						$this->create_shout($uid, "User {$username} was banned from the shout with total of votes: {$record}", true);			
						echo "User {$username} was banned from the shout. Total of votes: {$record} / {$total}";
						
					}
					else
					{
						$update = array('ban_votes' => (int)$record);
						$update2 = array('ban_votes_add' => 1);
						$this->db->update_query('inferno_user',$update,'uid='.(int)$touid);
						$this->db->update_query('inferno_user',$update2,'uid='.(int)$uid);
						$this->create_shout($uid, "Vote to ban {$username} was added success. Total of votes: {$record}", true);						
						echo "Your vote for ban to {$username} was added success. Total of votes: {$record}";
					}
				}
				else
				{
					$user =	get_user($touid);
					$username = htmlspecialchars_uni($user['username']);				
					echo "Your vote for {$username} can not be processed due he is not into our shoutbox database yet...";				
				}				
			}
			else
			{
				echo "You can not vote more than one time to ban users, until next votation";
			}
		}
		else if($total == 0)
		{
			echo "Admin have to set a total ammount to vote bans";
			exit;
		}
		else
		{
			echo "Your vote for ban can not be processed";
			exit;
		}
	}
	
	public function update_config($twich_mode, $vote_ban, $vote_ban_total)
	{
		require_once(MYBB_ROOT . 'inc/plugins/inferno/config.php');
		$twich_mode = $inferno_config['twich_mode'];
		$vote_ban	= $inferno_config['vote_ban'];
		$vote_ban_total  = $inferno_config['vote_ban_total'];
		$twich_mode_total = $inferno_config['twich_mode_total'];
		$twich_mode_count = $inferno_config['twich_mode_count'];
		$twich_mode = (int)$twich_mode;
		$vote_ban = (int)$vote_ban;
		$vote_ban_total = (int)$vote_ban_total;
		$twich_mode_total = (int)$twich_mode_total;
		$twich_mode_count = (int)$twich_mode_count;
		$fp = fopen(MYBB_ROOT . 'inc/plugins/inferno/config.php', 'w');
		$data = "<?php
	/** THIS IS A CONFIGURATION FILE **/		
	\$inferno_config = array(
		'twich_mode' => ".$twich_mode.",
		'twich_mode_total' => ".$twich_mode_total.",
		'twich_mode_count' => ".$twich_mode_count.",	
		'vote_ban' => ".$vote_ban.",
		'vote_ban_total' => ".$vote_ban_total.",
	);";
		fwrite($fp, $data);
		return fclose($fp);
	}

	public function verify_can_vote($uid)
	{
		$verify_can_vote = $this->db->simple_select('inferno_user','twich_votes_add','twich_votes_add=1 AND uid='.(int)$uid);
		if($this->db->num_rows($verify_can_vote) == 0)
		{
			$this->db->update_query('inferno_user',array('twich_votes_add'=>1),'uid='.(int)$uid);
			return true;
		}
		return false;
	}
	
	public function update_ban_totals()
	{
		$this->db->update_query('inferno_user',array('ban_votes' => 0,'ban_votes_add' => 0),'ban_votes>0 OR ban_votes_add>0');
		echo "All counters was set to 0 until the next ban votations.";
	}
	
	public function update_twich_counters()
	{
		$this->db->update_query('inferno_user',array('twich_votes_add' => 0),'twich_votes_add>0');
		echo "All counters was set to 0 until the next ban Twich Mode.";		
	}
	
	public function create_shout($uid, $shout, $me = 0, $pm = 0)
	{
		$uid = (int) $uid;
		$me = ($me) ? 1 : 0;
		$pm = (int) $pm;

		if (!$this->fetch_userinfo($uid))
		{
			$this->create_user($uid);
		}

		if (!$this->is_valid_shout($shout))
		{
			return false;
		}
		
		if($this->settings['inferno_parse_youtube_videos'] == 0)
		$shout = $this->convertYoutube($shout);

		$query1 = $this->db->insert_query('inferno_shout', array(
			'sid' 		=> '0',
			'uid' 		=> (int)$uid,
			'shout' 	=> $this->clean_shout($shout),
			'me' 		=> $me,
			'private' 	=> $pm,
			'is_read' => 1,
			'whisper'	=> 0,
			'timestamp'	=> TIME_NOW
		));
		if($pm)
		{
			$query2 = $this->db->update_query('inferno_user', array(
				'dateline' => TIME_NOW,
				'is_online' => 1
			), "uid='{$uid}'");
			$query = $this->db->simple_select('inferno_user','*','uid='.(int)$pm);
			$result = $this->db->fetch_field($query,'unread_pms');
			$query3 = $this->db->update_query('inferno_user', array(
				'unread_pms' => (int)$result+1
			), "uid='{$pm}'");
		}
		else
		{
			$query2 = $this->db->update_query('inferno_user', array(
				'dateline' => TIME_NOW,
				'is_online' => 1
			), "uid='{$uid}'");
			$query3 = "";
		}
		$this->update_anus();

		return ($query1 && $query2 && $query3);
	}

	public function create_shout_whisper($uid, $shout, $whisper = 0)
	{
		$uid = (int) $uid;
		$whisper = (int)$whisper;

		if ($uid > 0 && !$this->fetch_userinfo($uid))
		{
			$this->create_user($uid);
		}

		if (!$this->is_valid_shout($shout))
		{
			return false;
		}
		
		$result = $this->db->simple_select('inferno_user','COUNT(*) as Result','uid='.(int)$whisper.' AND dateline>' . (TIME_NOW - ($this->settings['inferno_shoutbox_cutoff'] * 60)));
		$res = $this->db->fetch_field($result, 'Result');
		if(!$res)
		{
			$user = $this->db->simple_select('users','username','uid='.(int)$whisper);
			$uname = $this->db->fetch_field($user,'username');
			echo("User {$uname} have to be online to receive whispers...");
			return false;
		}
		
		if($this->settings['inferno_parse_youtube_videos'] == 0)
		$shout = $this->convertYoutube($shout);

		$query1 = $this->db->insert_query('inferno_shout', array(
			'sid' 		=> '0',
			'uid' 		=> (int)$uid,
			'shout' 	=> $this->clean_shout($shout),
			'me' 		=> 0,
			'private' 	=> 0,
			'is_read' => 1,
			'whisper' 	=> (int)$whisper,			
			'timestamp'	=> TIME_NOW
		));

		$query = $this->db->simple_select('inferno_user','*','uid='.(int)$whisper);
		$result = $this->db->fetch_field($query,'whispers');		
		$query2 = $this->db->update_query('inferno_user', array(
			'dateline' => TIME_NOW,
			'whispers' => (int)$result+1,
		), "uid='{$whisper}'");

		$this->update_anus();
		return ($query1 && $query2);
	}
	
	public function prune($uid = 0)
	{
		$uid = (int) $uid;
		if ($uid)
		{
			$query = $this->db->delete_query("inferno_shout", "uid = '{$uid}';");
			$this->lang->shout_pruned = $this->lang->sprintf($this->lang->shout_pruned, $uid);
			$this->log($this->lang->shout_pruned);
		}
		else
		{
			$query = $this->db->query("TRUNCATE " . TABLE_PREFIX . "inferno_shout");
			$this->log($this->lang->shout_cleaned);
		}
		return $query;
	}

	public function prune_days($days = 0)
	{
		$days = (int) $days;
		if ($days > 0)
		{
			$time = TIME_NOW - ($days * 86400); // Días de referencia
			$query = $this->db->delete_query("inferno_shout", "timestamp <= '{$time}'");
			$this->lang->shout_pruned = $this->lang->sprintf($this->lang->shout_pruned, $days);
			$this->log($this->lang->shout_pruned);
		}
		return $query;
	}

	public function delete_shout($shoutid)
	{
		$shoutid = (int) $shoutid;
		$shoutinfo = $this->get_shout($shoutid);
		$query = $this->db->delete_query("inferno_shout", "sid='{$shoutid}'");
		if ($query)
		{
			$this->update_anus();
			$this->lang->shout_deleted = $this->lang->sprintf($this->lang->shout_deleted, $shoutinfo['uid'], $shoutid);
			$this->log($this->lang->shout_deleted);
		}
		return ($query) ? true : false;
	}

	public function remove_shout($shoutid)
	{
		$shoutid = (int) $shoutid;
		$shoutinfo = $this->get_shout($shoutid);
		$query = $this->db->delete_query("inferno_shout", "sid='{$shoutid}'");
		if ($query)
		{
			$this->update_anus();
			$this->lang->shout_deleted = $this->lang->sprintf($this->lang->shout_deleted, $shoutinfo['uid'], $shoutid);
			$this->log($this->lang->shout_deleted);
		}
		return ($query) ? true : false;
	}

	public function ban_full_user($userid)
	{
		$userid = (int) $userid;
		$fromid = (int) $this->mybb->user['uid'];
		$query = $this->db->simple_select('inferno_banned_users', '*', 'ban_uid='.$userid);
		if($this->db->num_rows($query) == 0)
		{
			$query_insert = $this->insert_bannedinfo(array(
				'ban_uid' => (int)$userid,
				'ban_by' => (int)$fromid,
				'ban_reason' => "Permanent",
				'ban_start' => time(),
				'ban_end' => -1
			), $userid);
			$query_update = $this->db->update_query('inferno_user',array('banned'=>1),' uid='.$userid);			
			return ($query_insert.$query_update) ? true : false;
		}
	}

	public function ban_user($userid)
	{
		$userid = (int) $userid;
		$fromid = (int) $this->mybb->user['uid'];
		$query = $this->db->simple_select('inferno_banned_users', '*', 'ban_uid='.$userid);
		if($this->db->num_rows($query) == 0)
		{
			$queryu = $this->db->simple_select('users','username','uid='.$userid);
			$user_to = $this->db->fetch_field($queryu, 'username');
			$user_to = htmlspecialchars_uni($user_to);
			$user = htmlspecialchars_uni($this->mybb->user['username']);
			$shout = "{$user} has banned {$user_to} with no reason for 24 hours";	
			$data_sb = array(
				"uid" => (int)$fromid,
				"shout" => $this->db->escape_string($shout),
				"me" => 1,
				"private" => 0,
				"timestamp" => TIME_NOW
			);
			$this->db->insert_query('inferno_shout',$data_sb);
			$query_insert = $this->insert_bannedinfo(array(
				'ban_uid' => (int)$userid,
				'ban_by' => (int)$fromid,
				'ban_reason' => "No reason",
				'ban_start' => time(),
				'ban_end' => time() + 24 * 60 * 60
			), $userid);
			$query_update = $this->db->update_query('inferno_user',array('banned'=>1),' uid='.$userid);			
			return ($query_insert.$query_update) ? true : false;
		}
	}
	
	public function is_admin($groupid)
	{
		$admins = $this->get_setting_array('usergroups_admin', ',');
		return in_array($groupid, $admins);
	}

	public function get_user_data($uid = 0)
	{
		$user = [];
		$query = $this->db->query("
			SELECT iu.*, u.username
			FROM " . TABLE_PREFIX . "inferno_user iu
				LEFT JOIN " . TABLE_PREFIX . "users u
				ON iu.uid = u.uid
			WHERE iu.uid=". (int) $uid
		);
		$user = $this->db->fetch_array($query);
		return $user;
	}

	public function get_shouts($pmonly = 0, $archive = false, $end_limit = 0)
	{
		require_once MYBB_ROOT . 'inc/class_parser.php';
		$parser = new postParser();
		$pmonly = (int) $pmonly;
		if(isset($whisper))
		{
			$whisper = (int) $whisper;
		}
		else
		{
			$whisper = 0;
		}
		$where = "";
		$parse_options = array(
			'allow_html' 	=> false,
			'allow_mycode' 	=> (bool) $this->settings['inferno_allow_mycode'],
			'allow_smilies'	=> (bool) $this->settings['inferno_smilies'],
			'allow_imgcode' => true,
			'filter_badwords' => (bool) $this->settings['inferno_filter_badwords'],
			'allow_videocode' => true
		);
		$archive_per_page = (int)$this->settings['inferno_archive_shouts_per_page'];
		$shouts_per_page = (int) $this->settings['inferno_shouts_display'];
		$shouts = array();
		if(isset($this->mybb->input['action']) && $this->mybb->input['action'] == "archive")
			$limit = (int) $archive_per_page;
		else
			$limit = (int) $shouts_per_page;
		$limit = (!$end_limit) ? $limit : $limit . ', ' . (int) $end_limit;
		$order = ($this->settings['inferno_shout_order']) ? 'DESC' : 'ASC';

		if (!$pmonly && isset($this->mybb->input['action']) && $this->mybb->input['action'] != "archive")
		{
			$where = "
			WHERE
			(
				(
					(s.private = '0' AND s.whisper = '0')
					OR
					(s.private = '{$this->userinfo['uid']}')
					OR
					(s.private != '0' AND s.uid = '{$this->userinfo['uid']}')
					OR
					(s.private = '0' AND s.whisper = '{$this->userinfo['uid']}')	
					OR
					(s.whisper != '0' AND s.uid = '{$this->userinfo['uid']}')					
				)
				AND
				(
					(u.silenced = '0')
			 		OR
					(u.silenced = '1' AND u.uid = '{$this->userinfo['uid']}')
				)
			)";
		}
		else if($pmonly || isset($this->mybb->input['action']) && $this->mybb->input['action'] == "archive")
		{
			$where = "
			WHERE
			(
				(
					(s.private = '{$pmonly}')
					OR
					(s.uid = '{$pmonly}' AND s.private>0)
				)
				AND
				(
					(u.silenced = '0')
			 		OR
					(u.silenced = '1' AND u.uid = '{$this->userinfo['uid']}')
				)
			)";
		}
		$result = $this->db->query("
			SELECT s.*, u.*
			FROM " . TABLE_PREFIX . "inferno_shout s
			LEFT JOIN " . TABLE_PREFIX . "inferno_user u
			ON s.uid = u.uid
			{$where}
			ORDER BY s.sid {$order}
			LIMIT {$limit};
		");

		$usercache = array();

		while ($row = $this->db->fetch_array($result))
		{
			// Markup Username
			if (isset($usercache[$row['uid']]))
			{
				$shout_user = $usercache[$row['uid']];
			}
			else
			{
				$shout_user = get_user($row['uid']);
				$usercache[$row['uid']] = $shout_user;
			}
			$avi_pixels = intval($this->settings['inferno_avatars']);
			if(!isset($shout_user['avatar']) || isset($shout_user['avatar']) && $shout_user['avatar'] == ''){
				if(!isset($shout_user['username']))
				{
					$shout_user = ['username' => $this->lang->guest, 'usergroup' => 1, 'displaygroup' => 1];
				}
				preg_match('/^[a-z]/i', $shout_user['username'], $res);
				$resultado = empty($res) ? '?' : $res[0][0];
				$user_hash = md5($shout_user['username']);
				$random_color = substr($user_hash, 0, 6);
				$row['avatar'] = '<span class="shoutbox_avatar_letter" style="background-color:#'.$random_color.';" >'.$resultado.'</span>';
			}
			else{
				$row['avatar'] = '<img alt="' . htmlspecialchars_uni($shout_user['username']) . '" src="' .  $this->mybb->settings['bburl'] . '/' . htmlspecialchars_uni($shout_user['avatar']) . '" height="' . $avi_pixels .'" width="' . $avi_pixels .'" class="chat_avatar" />';
			}

			if($row['uid'] > 0)
			{
				$row['username'] = format_name($shout_user['username'], $shout_user['usergroup'], $shout_user['displaygroup']);
				$row['userlink'] = get_profile_link($row['uid']);
				if(isset($this->userinfo['uid']) && $row['uid'] == $this->userinfo['uid'])
					$row['modals'] = '<ul class="sbcount shoutcount'.$row['sid'].'" onmouseleave="javascript: inferno.remove_modal_user('.$row['uid'].');return false;"><li style="cursor:pointer;" onclick="location.href=\''.$this->mybb->settings['bburl']."/".$row['userlink'].'\'"><i class="fa fa-user-circle">&nbsp;</i>'.$this->lang->isb_my_profile.'</li><li style="cursor:pointer;" onclick="javascript: inferno.add_private_chat(' . $row['uid'] . ', \'' . $shout_user['username'] . '\'); return false;"><i class="fa fa-envelope">&nbsp;</i>'.$this->lang->isb_private.'</li><li style="cursor:pointer;" onclick="javascript: inferno.add_whisper_chat(' . $row['uid'] . ', \'' . $shout_user['username'] . '\'); return false;"><i class="fa fa-ticket">&nbsp;</i>'.$this->lang->isb_whisper.'</li><li style="cursor:pointer;" onclick="javascript: inferno.remove_modal_user('.$row['uid'].');return false;"><i class="fa fa-times-circle">&nbsp;</i>'.$this->lang->isb_close.'</li></ul>';
				else
					$row['modals'] = '<ul class="sbcount shoutcount'.$row['sid'].'" onmouseleave="javascript: inferno.remove_modal_user('.$row['uid'].');return false;"><li style="cursor:pointer;" onclick="location.href=\''.$this->mybb->settings['bburl']."/".$row['userlink'].'\'"><i class="fa fa-user-circle">&nbsp;</i>'.$this->lang->isb_user_profile.'</li><li style="cursor:pointer;" onclick="javascript: inferno.add_private_shout(' . $row['uid'] . '); return false;"><i class="fa fa-envelope">&nbsp;</i>'.$this->lang->isb_send_private.'</li><li style="cursor:pointer;" onclick="javascript: inferno.add_whisper(' . $row['uid'] . '); return false;"><i class="fa fa-ticket">&nbsp;</i>'.$this->lang->isb_send_whisper.'</li><li style="cursor:pointer;" onclick="inferno.insertUser(\''.$shout_user['username'].'\');return false;"><i class="fa fa-hashtag">&nbsp;</i>'.$this->lang->isb_mention.'</li><li style="cursor:pointer;" onclick="javascript: inferno.remove_modal_user('.$row['uid'].');return false;"><i class="fa fa-times-circle">&nbsp;</i>'.$this->lang->isb_close.'</li></ul>';
				$row['name'] = htmlspecialchars_uni($shout_user['username']);			
				if($row['is_read'] == 1)
					$row['marks'] = '<i class="fa fa-envelope" style="color:red">&nbsp;</i>';
				else
					$row['marks'] = '<i class="fa fa-envelope-open" style="color:white">&nbsp;</i>';
	
			}
			if(empty($row['username']))
			{
				$row['username'] = $this->lang->guest;
			}
			else
			{
				// markup so username is clickable
				if (!$pmonly && $this->settings['inferno_shoutbox_pm'] && $archive === false)
					$row['username'] = '<a href="javascript:void(0);" onclick="javascript: inferno.get_modal_user('.$row['sid'].','.$row['uid'].');return false;">' . $row['username'] . '</a>' . $row['modals'];
				else
					$row['username'] = '<a href="javascript:void(0);" onclick="javascript: inferno.add_private_shout(' . $row['uid'] . '); return false;">'.$row['marks'].$row['username'].'</a>';
			}

			// Remove unwanted mycode if not admin
			if (!$this->is_admin($shout_user['usergroup']))
			{
				$row['shout'] = $this->strip_mycode($row['shout']);
			}
			
			// parse images with link...
			$row['shout'] = preg_replace("#\[img\](\r\n?|\n?)(https?://([^<>\"']+?))\[/img\]#is", '[url=$2][img]$2[/img][/url]', $row['shout']);
			// show right chars due special escaped chars into shoutbox messages from db....
			$row['shout'] = preg_replace("#\&amp;#is", '&', $row['shout']);
			$row['shout'] = preg_replace("#\&quot;#is", '"', $row['shout']);
			$row['shout'] = preg_replace("#\&lt;#is", '<', $row['shout']);			
			$row['shout'] = preg_replace("#\&gt;#is", '>', $row['shout']);
			$row['shout'] = preg_replace("#\\\'#is", '\'', $row['shout']);			
			// Add new youtube links experience wip...
			if(isset($this->settings['inferno_parse_youtube_videos']) && $this->settings['inferno_parse_youtube_videos'] == 1)
			$row['shout'] = $this->convertYoutube($row['shout']);
			$row['shout'] = $parser->parse_message($row['shout'], $parse_options);
			$row['shout'] = $this->parse_mentions($row['shout']);
			
			if ($this->settings['inferno_shout_markup'])
			{
				$css = $this->render_css($row);

				if (!empty($css))
				{
					$row['shout'] = '<span style="' . $css . '">' . $row['shout'] . '</span>';
				}
			}

			// Markup Timestamp
			$unixtime = $row['timestamp'];
			if(!isset($this->mybb->user['timezone']))
			{
				$this->mybb->user['timezone'] = "";
			}
			$row['timestamp'] = my_date($this->settings['timeformat'], $unixtime, $this->mybb->user['timezone']);

			$shouts[] = $row;
		}
		if(isset($this->userinfo['uid']) && !$pmonly)
			$this->verify_unreads($this->userinfo['uid']);
		else if(isset($this->userinfo['uid']) && $pmonly)
			$this->verify_unreads_pms($pmonly);
		return $shouts;
	}

	public function get_whisper($whisper = 0, $archive = false, $end_limit = 0)
	{
		require_once MYBB_ROOT . 'inc/class_parser.php';
		$parser = new postParser();
		$whisper = (int)$whisper;
		$parse_options = array(
			'allow_html' 	=> false,
			'allow_mycode' 	=> (bool) $this->settings['inferno_allow_mycode'],
			'allow_smilies'	=> (bool) $this->settings['inferno_smilies'],
			'allow_imgcode' => true,
			'filter_badwords' => (bool) $this->settings['inferno_filter_badwords'],
			'allow_videocode' => true
		);

		$shouts = array();
		$limit = ($archive !== false) ? (int) $archive : (int) $this->settings['inferno_shouts_display'];
		$limit = (!$end_limit) ? $limit : $limit . ', ' . (int) $end_limit;
		$order = ($this->settings['inferno_shout_order']) ? 'DESC' : 'ASC';

		$where = "
		WHERE
		(
			(
				(s.whisper = '{$whisper}')
				OR
				(s.uid = '{$whisper}')
			)
			AND
			(
				(u.silenced = '0')
		 		OR
				(u.silenced = '1' AND u.uid = '{$this->userinfo['uid']}')
			)
		)";

		$result = $this->db->query("
			SELECT s.*, u.*
			FROM " . TABLE_PREFIX . "inferno_shout s
			LEFT JOIN " . TABLE_PREFIX . "inferno_user u
			ON s.uid = u.uid
			{$where}
			ORDER BY s.sid {$order}
			LIMIT {$limit};
		");

		$usercache = array();

		while ($row = $this->db->fetch_array($result))
		{
			// Markup Username
			if (isset($usercache[$row['uid']]))
			{
				$shout_user = $usercache[$row['uid']];
			}
			else
			{
				$shout_user = get_user($row['uid']);
				$usercache[$row['uid']] = $shout_user;
			}
			$avi_pixels = intval($this->settings['inferno_avatars']);
			if($shout_user['avatar'] == '')
			{
				preg_match('/^[a-z]/i', $shout_user['username'], $res);
				$resultado = empty($res) ? '?' : $res[0][0];
				$user_hash = md5($shout_user['username']);
				$random_color = substr($user_hash, 0, 6);
				$row['avatar'] = '<span class="shoutbox_avatar_letter" style="background-color:#'.$random_color.';" >'.$resultado.'</span>';
			}
			else
			{
				$row['avatar'] = '<img alt="' . htmlspecialchars_uni($shout_user['username']) . '" src="' .  $this->mybb->settings['bburl'] . '/' .  htmlspecialchars_uni($shout_user['avatar']) . '" height="' . $avi_pixels .'" width="' . $avi_pixels .'" class="chat_avatar" />';
			}
			$row['username'] = format_name($shout_user['username'], $shout_user['usergroup'], $shout_user['displaygroup']);
			$row['userlink'] = get_profile_link($row['uid']);
			$row['name'] = htmlspecialchars_uni($shout_user['username']);			
			if($row['is_read'] == 1)
				$row['markw'] = '<i class="fa fa-ticket" style="color:green">&nbsp;</i>';
			else
				$row['markw'] = '<i class="fa fa-ticket" style="color:white">&nbsp;</i>';
			$row['username'] = $row['markw'].'<a href="javascript:void(0);" onclick="javascript: inferno.add_whisper(' . $row['uid'] . '); return false;">'.$row['username'].'</a>';
				
			// Remove unwanted mycode if not admin
			if (!$this->is_admin($shout_user['usergroup']))
			{
				$row['shout'] = $this->strip_mycode($row['shout']);
			}

			// Add new youtube links experience wip...
			if($this->settings['inferno_parse_youtube_videos'] == 1)
			$row['shout'] = $this->convertYoutube($row['shout']);
			$row['shout'] = $parser->parse_message($row['shout'], $parse_options);
			$row['shout'] = $this->parse_mentions($row['shout']);
			
			if ($this->settings['inferno_shout_markup'])
			{
				$css = $this->render_css($row);

				if (!empty($css))
				{
					$row['shout'] = '<span style="' . $css . '">' . $row['shout'] . '</span>';
				}
			}

			// Markup Timestamp
			$unixtime = $row['timestamp'];
			$row['timestamp'] = my_date($this->settings['timeformat'], $unixtime, $this->mybb->user['timezone']);

			$shouts[] = $row;
		}
		$this->verify_unreads_whispers($whisper);
		return $shouts;
	}
	
	public function verify_unreads($uid)
	{
		$this->db->update_query('inferno_shout',array('is_read' => 0),'private=0 AND whisper=0 AND uid='.(int)$uid);
	}

	public function verify_unreads_whispers($uid)
	{
		$this->db->update_query('inferno_shout',array('is_read' => 0),'whisper='.(int)$uid);
		$this->db->update_query('inferno_user',array('whispers' => 0),'uid='.(int)$uid);
	}
	
	public function verify_unreads_pms($uid)
	{
		$this->db->update_query('inferno_shout',array('is_read' => 0),'private='.(int)$uid);
		$this->db->update_query('inferno_user',array('unread_pms' => 0),'uid='.(int)$uid);
	}
	
	public function retrieve_user_shouts($uid)
	{
		$result = [];
		$query = $this->db->query("
			SELECT COUNT(sb.sid) AS Total, sb.uid, u.username, u.usergroup, u.displaygroup
			FROM ".TABLE_PREFIX."inferno_shout sb
			LEFT JOIN ".TABLE_PREFIX."users u ON sb.uid = u.uid
			WHERE sb.uid = " . (int) $uid . "
			GROUP BY sb.uid, u.username, u.usergroup, u.displaygroup, u.avatar
		");
		$result = $this->db->fetch_array($query);
		return $result;
	}

	public function get_smilies()
	{
		if($this->settings['inferno_smilies_limit'] == '')
			return false;
		$smilies = [];
		$html = '';
		$limit = $this->settings['inferno_smilies_limit'] ? ' LIMIT ' . $this->settings['inferno_smilies_limit'] : '';
		$query = $this->db->query("SELECT * FROM " . TABLE_PREFIX . "smilies" . $limit);
		while ($s = $this->db->fetch_array($query))
		{
			$smilies[] = $s;
		}
		shuffle($smilies);
		foreach ($smilies as $s)
		{
			$html .= '<a href="#" onclick="javascript: inferno.append(\'' . $s['find'] . '\'); return false;"><img title="' . $s['name'] . '" src="' . $this->mybb->settings['bburl'] . "/". $s['image'] . '" /></a> ';
		}
		return trim($html);
	}

	// START Add new youtube links experience wip...
	public function convertYoutube($string)
	{
		$youtube_api_key = $this->settings['inferno_shoutbox_youtube_api'];
		if(isset($youtube_api_key) && !empty($youtube_api_key))
		{
			$replace = array();
			$youtubeRegexp = "/\s*[a-zA-Z\/\/:\.]*youtu(be.com\/watch\?v=|.be\/)([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/is";
			$match = preg_match_all($youtubeRegexp, $string, $matches, PREG_SET_ORDER);
			$string = preg_replace($youtubeRegexp, "$2", $string);
			for ($n=0;$n<$match;$n++)
			{
				$replace = $this->get_video_data($matches[$n][2]);
				$string = preg_replace("/{$matches[$n][2]}/is", $replace, $string, 1);
			}
			$data = $string;
		}
		else
			$data = preg_replace("/\s*[a-zA-Z\/\/:\.]*youtu(be.com\/watch\?v=|.be\/)([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/is",$this->get_video_data("$2"),$string);		
		return $data;
	}
	
	public function parse_mentions($message)
	{
		global $mybb;

		$email_regex = "#\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b#i";
		preg_match_all($email_regex, $message, $emails, PREG_SET_ORDER);
		$message = preg_replace($email_regex, "<mybb-email>\n", $message);
		$message = preg_replace_callback('/@[\'|"|`]([^<]+?)[\'|"|`]|@([\w .]{' . (int) $mybb->settings['minnamelength'] . ',' . (int) $mybb->settings['maxnamelength'] . '})/', 'inferno_mention_filter_callback', $message);
	
		// now restore the email addresses
		foreach($emails as $email)
		{
			$message = preg_replace("#\<mybb-email>\n?#", $email[0], $message, 1);
		}
		return $message;
	}

	public function get_banned_list()
	{
		global $header, $headerinclude, $footer, $ban_list_rows, $ban_list;
		$ban_list = '';
		$page = 1;
		if(isset($this->mybb->input['page']))
			$page = (int)$this->mybb->input['page'];
		$totals = $this->db->query("SELECT COUNT(*) AS numtot FROM " . TABLE_PREFIX . "inferno_user WHERE banned=1");
		$numtot = $this->db->fetch_field($totals,'numtot');
		$perpage = 10;
		$banned_users = (int)$numtot;
		$multipage = multipage($numtot, $perpage, $page, $_SERVER['PHP_SELF']."?action=inferno_banned_list");
		
		$query = $this->db->query("
			SELECT iu.uid, iu.banned, ibu.*, u.username as ban_username, u.usergroup as ban_usergroup, u.displaygroup as ban_displaygroup, um.username as banby_username, um.usergroup as banby_usergroup, um.displaygroup as banby_displaygroup
				FROM " . TABLE_PREFIX . "inferno_user iu
			LEFT JOIN " . TABLE_PREFIX . "inferno_banned_users ibu
				ON (iu.uid = ibu.ban_uid)
			LEFT JOIN " . TABLE_PREFIX . "users u
				ON (iu.uid = u.uid)
			LEFT JOIN " . TABLE_PREFIX . "users um
				ON (ibu.ban_by = um.uid)			
			WHERE iu.banned=1
			ORDER BY ban_end ASC
			LIMIT ".(($page-1)*$perpage).", {$perpage}	
		");
	
		while ($row = $this->db->fetch_array($query))
		{
			$ban_user = htmlspecialchars_uni($row['ban_username']);
			$ban_user = format_name($row['ban_username'], $row['ban_usergroup'], $row['ban_displaygroup']);
			$ban_user = build_profile_link($ban_user, $row['ban_uid']);		
			if(!empty($row['banby_username']))
			{
				$ban_by = htmlspecialchars_uni($row['banby_username']);
				$ban_by = format_name($row['banby_username'], $row['banby_usergroup'], $row['banby_displaygroup']);
				$ban_by = build_profile_link($ban_by, $row['ban_by']);
				$reason = $row['ban_reason'];
				if($row['ban_end'] == -1)
					$unban = $this->lang->isb_never;
				else
					$unban = my_date($this->mybb->settings['dateformat'], $row['ban_end']);			
			}
			else
			{
				$ban_by = $this->lang->isb_some_moderator;
				$reason = $this->lang->isb_unknow;
			}	
			$unban_button = "<a id=\"unban{$row['uid']}\" href=\"{$this->mybb->settings['bburl']}/infernoshout.php?action=unbanUser&uid={$row['uid']}\" class=\"button\">{$this->lang->isb_unban_now}</a>
			<script type=\"text/javascript\">
			$(function(){
				$(\"#unban{$row['uid']}\").on(\"click\", function(e){
					e.preventDefault();
					$.get(\"infernoshout.php?action=unbanUser&uid={$row['uid']}\",function(request){
						$(\"#resultban{$row['uid']}\").html(request);
						$(\"#total_banned\").remove();
					});
				});
			});
			</script>";		
			eval("\$ban_list_rows .= \"".$this->templates->get("inferno_banned_list_rows", 1, 0)."\";");		
		}

		eval("\$ban_list = \"".$this->templates->get("inferno_banned_list", 1, 0)."\";");
		echo $ban_list;
	}

	public function get_video_data($id)
	{
		$youtube_api_key = $this->settings['inferno_shoutbox_youtube_api'];
		$video_id = $id;
		if(isset($youtube_api_key) && !empty($youtube_api_key))
		{
			$url = "https://www.googleapis.com/youtube/v3/videos?id={$video_id}&key={$youtube_api_key}&part=snippet,contentDetails,statistics";
			$json = file_get_contents($url,0,null,0);
			$json_output = json_decode($json);
			$data = $json_output->items[0];
			//foreach ($json_output->items as $data)
			if(!empty($data->id))
			{
				$hours = explode("PT",$data->contentDetails->duration);
				$hours[1] = str_replace("H","",$hours[1]);			
				$minutes = explode("M",$data->contentDetails->duration);		
				$minutes[0] = str_replace("PT","",$minutes[0]);
				$minutes[0] = str_replace("M","",$minutes[0]);	
				$minutes[1] = str_replace("S","",$minutes[1]);
				if($hours[0] < 1)
					$hours[0] = "00";
				else if($hours[0] < 10)
					$hours[0] = "0".$hours[0];
				if($minutes[0] < 1)
					$minutes[0] = "00";
				else if($minutes[0] < 10)
					$minutes[0] = "0".$minutes[0];
				if($minutes[1] < 1)
					$minutes[1] = "00";
				else if($minutes[1] < 10)
					$minutes[1] = "0".$minutes[1];
				$data->times = "{$hours[0]}:{$minutes[0]}:{$minutes[1]}";
				$replace = " [[url=https://www.youtube.com/watch?v={$data->id}]{$this->lang->isb_link} [color=#cc3333]{$this->lang->isb_youtube}[/color][/url]] [[b]{$this->lang->isb_title}[/b] {$data->snippet->title}] [[b]{$this->lang->isb_channel}[/b] {$data->snippet->channelTitle}] [[b]{$this->lang->isb_time}[/b] {$data->times}] [[b]{$this->lang->isb_views}[/b] {$data->statistics->viewCount}] [[b]{$this->lang->isb_likes}[/b] [color=#339933]+{$data->statistics->likeCount}[/color] [color=#cc3333]-{$data->statistics->dislikeCount}[/color]] ";				
			}
			else
				$replace = "[video=youtube]https://www.youtube.com/watch?v={$video_id}[/video]";
		}
		else
			$replace = "[video=youtube]https://www.youtube.com/watch?v={$video_id}[/video]";
		return $replace;
	}
	// END Add new youtube links experience wip...

	public function strip_mycode($string)
	{
		$disallowed = explode(',', $this->settings['inferno_banned_mycode']);

		foreach ($disallowed as $code)
        {
       		$string = preg_replace_callback('#(\[' . $code . '(?:.*?)\](.*?)\[\/' . $code . '\])#', function($matches) {return empty($matches[2]) ? "." : $matches[2];}, $string);
        }

		return $string;
	}

	public function update_shout($sid, $value)
	{
		$sid = (int) $sid;
		$value = $this->db->escape_string($value);
		$query = $this->db->update_query('inferno_shout', array(
			'shout' => $value
		), "sid='{$sid}'");

		if ($query)
		{
			$this->update_anus();
		}
		return ($query) ? true : false;
	}

	public function get_shout($id)
	{
		$id = (int) $id;
		$query = $this->db->query("SELECT * FROM " . TABLE_PREFIX . "inferno_shout WHERE sid='{$id}'");
		$result = $this->db->fetch_array($query);
		return ($result) ? $result : false;
	}

	public function make_editable($shout, $id)
	{
		$string = '<div ondblclick="javascript: inferno.edit_shout(' . $id . '); return false;">' . $shout . '</div>';
		return $string;
	}

	public function render_css($array)
	{
		global $mybb;
		$css = '';
		if (!empty($array['bold']) && $mybb->settings['inferno_button_bold'] == 1)
		{
			$css .= 'font-weight:bold;';
		}
		if (!empty($array['italic']) && $mybb->settings['inferno_button_italic'] == 1)
		{
			$css .= 'font-style:italic;';
		}
		if (!empty($array['underline']) && $mybb->settings['inferno_button_underline'] == 1)
		{
			$css .= 'text-decoration:underline;';
		}
		if (!empty($array['color']) && $mybb->settings['inferno_button_colors'] == 1)
		{
			$css .= 'color:' . $array['color'] . ';';
		}
		if (!empty($array['font']) && $mybb->settings['inferno_button_fonts'] == 1)
		{
			$css .= 'font-family:' . $array['font'] . ';';
		}
		return $css;
	}

	public function fetch_active_users()
	{
		$users = array();
		$result = $this->db->query("
			SELECT *
			FROM " . TABLE_PREFIX . "inferno_user
			WHERE dateline > " . (TIME_NOW - ($this->settings['inferno_shoutbox_cutoff'] * 60)) . "
		");
		$this->db->update_query('inferno_user',array("is_online" => 0),'is_online=1 AND dateline <= ' . (TIME_NOW - ($this->settings['inferno_shoutbox_cutoff'] * 60)));
		while ($row = $this->db->fetch_array($result))
		{
			$shout_user = get_user($row['uid']);
			$row['username'] = format_name($shout_user['username'], $shout_user['usergroup'], $shout_user['displaygroup']);
			$row['userlink'] = get_profile_link($row['uid']);
			if(isset($row['sid']))
			$row['modals'] = '<li class="items"><i class="fa fa-user">&nbsp;</i><span class="shoutdata'.(int)$row['sid'].'">' . htmlspecialchars_uni($row['username']) . ' # '.(int)$row['uid'].'</span></li><li class="items"><i class="fa fa-comments">&nbsp;</i>Total Shouts: '.$row['messages'].'</li>';
			$users[] = $row['username'];
		}

		return $users;
	}
	
	public function gen_profile_link($text, $uid)
	{
		return '<a href="' . $this->settings['bburl'] . '/' . get_profile_link($uid) . '">' . $text . '</a>';
	}


	public function render_notice()
	{
		$string = $this->settings['inferno_shoutbox_notice'];
		require_once MYBB_ROOT . 'inc/class_parser.php';
		$parser = new postParser();

		$parse_options = array(
			'allow_html' 	=> false,
			'allow_mycode' 	=> (bool) $this->settings['inferno_allow_mycode'],
			'allow_smilies'	=> (bool) $this->settings['inferno_smilies']
		);

		return $this->lang->sprintf($this->lang->isb_c_notice_msg, $parser->parse_message($string, $parse_options));
	}

	public function update_notice($string = '')
	{
		$string = $this->db->escape_string($string);
		$logger = (empty($string)) ? 'has deleted the notice' : 'has changed to: ' . $string;
		$this->log($logger);

		$var = $this->db->update_query('settings', array(
			'value' => $string
		), 'name = \'inferno_shoutbox_notice\'');

		rebuild_settings();

		$this->update_anus();

		return $var;
	}

	/**
	 * Replace {inferno_*} variables in Inferno Templates
	 *
	 * @param string $string Template
	 * @return object
	 */
	public function replace_template_vars($string)
	{
		$boldarray = ['inferno_button_bold',''];
		$underlinearray = ['inferno_button_underline', ''];
		$italicarray = ['inferno_button_italic', ''];
		if(isset($this->userinfo['bold']))
		{
			$boldarray = [
				'inferno_button_bold',
				'<input type="button" class="button" onclick="javascript: inferno.update_style(\'bold\', this); return false;" style="font-weight: bold;" value="B' . (($this->userinfo['bold']) ? '*' : '') . '"/>'
			];
		}
		if(isset($this->userinfo['underline']))
		{
			$underlinearray = [
				'inferno_button_underline',
				'<input type="button" class="button inferno_underline" onclick="javascript: inferno.update_style(\'underline\', this); return false;" style="text-decoration:underline;" value="U' . (($this->userinfo['underline']) ? '*' : '') .'"/>'
			];
		}
		if(isset($this->userinfo['italic']))
		{
			$italicarray = [
				'inferno_button_italic',
				'<input type="button" class="button inferno_italic" onclick="javascript: inferno.update_style(\'italic\', this); return false;" style="font-style: italic;" value="I' . (($this->userinfo['italic']) ? '*' : '') . '"/>'
			];

		}
		$replace_vars = array(
			array(
				'inferno_shoutbox_title',
				$this->settings['inferno_shoutbox_title']
			),
			array(
				'inferno_css_height',
				$this->settings['inferno_css_height']
			),
			$boldarray,
			$underlinearray,
			$italicarray,
			array(
				'inferno_button_colors',
				$this->render_select_box('color')
			),
			array(
				'inferno_button_fonts',
				$this->render_select_box('font')
			),
			array(
				'inferno_button_smilies',
				'<input type="button" class="button" name="btnSmilies" id="smiliesbutton" onclick="javascript:inferno.toggle_smilies(); return false;" value="' . $this->lang->isb_btn_smilies . '"/>'
			),
			array(
				'inferno_active_users',
				count($this->fetch_active_users())
			),
			array(
				'inferno_user_css',
				$this->render_css($this->userinfo)
			),
			array(
				'inferno_version',
				$this->version
			),
			array(
				'inferno_archive_shouts',
				$this->gen_archive()
			),
			array(
				'inferno_archive_nav',
				$this->gen_archive_nav()
			),
			array(
	'inferno_post_key',
	$this->mybb->post_code
)
			
		);

		foreach ($replace_vars as $v)
		{
			if (isset($this->settings[$v[0]]) && !$this->settings[$v[0]])
			{
				$v[1] = '';
			}
			
			$string = str_replace('{' . $v[0] . '}', $v[1], $string);
		}

		return $string;
	}

	public function gen_archive_nav()
	{
		global $total_pages, $page;

		$html = '<tr><td class="tcat" align="center">';

		$jump = 3;
		$jumpback = ($page - $jump > 0) ? $page - $jump : false;
		$back = ($page - 1 > 0) ? $page - 1 : false;
		$forward = ($page + 1 <= $total_pages) ? $page + 1 : false;
		$jumpforward = ($page + $jump <= $total_pages) ? $page + $jump : false;

		$html .= '<b>' . $this->lang->isb_archive_page . ' <input type="text" id="a_page" style="width:30px; text-align:center;" value="' . $page . '" />/' . $total_pages . '</b>
			<input onclick="load_from_text();" type="button" class="button" value="' . $this->lang->isb_archive_btn_go . '" />
			<br />
		';

		if ($jumpback)
		{
			$html .= '<input onclick="load(' . $jumpback . ');" type="button" class="button" value="<<" />';
		}
		if ($back)
		{
			$html .= '<input onclick="load(' . $back . ');" type="button" class="button" value="<" />';
		}
		if ($forward)
		{
			$html .= '<input onclick="load(' . $forward . ');" type="button" class="button" value=">" />';
		}
		if ($jumpforward)
		{
			$html .= '<input onclick="load(' . $jumpforward . ');" type="button" class="button" value=">>" />';
		}

		$html .= '</td></tr>';

		return $html;
	}

	public function gen_archive()
	{
		global $mybb, $total_pages, $page, $offset, $shouts_per_page;
		$shouts = $this->get_shouts(false, false, $offset, $shouts_per_page);
		$html = '';
		$i = 0;
		foreach ($shouts as $s)
		{
			if ($s['me'])
			{
				$shoutdata = '<div class="sb_shouts_archive"><div class="shout_mine">' . $s['avatar'] . $s['username'] . '</div><div class="inferno_separator">:</div><div class="chat_normal_shout">' . $s['shout'] . '</div><div class="chat_date_shout">[' . $s['timestamp'] . ']*</div></div>';
			}
			else
			{
				if($mybb->user['uid'] == $s['uid'])
					$shoutdata = '<div class="sb_shouts_archive"><div class="shout_mine">' . $s['avatar'] . $s['username'] . '</div><div class="inferno_separator">:</div><div class="chat_normal_shout">' . $s['shout'] . (($s['private']) ? '<div class="chat_private_shout">[M.P]</div> ' : '') . '</div><div class="chat_date_shout">[' . $s['timestamp'] . ']</div></div>';
				else
					$shoutdata = '<div class="sb_shouts_archive"><div class="shout_user">' . $s['avatar'] . $s['username'] . '</div><div class="inferno_separator">:</div><div class="chat_normal_shout">' . $s['shout'] . (($s['private']) ? '<div class="chat_private_shout">[M.P]</div> ' : '') . '</div><div class="chat_date_shout">[' . $s['timestamp'] . ']</div></div>';
			}

			$css = ($i % 2) ? 'trow1' : 'trow2';
			$html .= '<tr><td class="' . $css . '">';
			$html .= $shoutdata;
			$html .= '</td></tr>';
			$i++;
		}

		return $html;
	}

	public function count_total_shouts()
	{
		$where = "
		WHERE
		(
			(
				(s.private = '0')
				OR
				(s.private = '{$this->userinfo['uid']}')
				OR
				(s.private != '0' AND s.uid = '{$this->userinfo['uid']}')
			)
			AND
			(
				(u.silenced = '0')
		 		OR
				(u.silenced = '1' AND u.uid = '{$this->userinfo['uid']}')
			)
		)";
		$query = $this->db->query("
			SELECT COUNT(*) as total
			FROM " . TABLE_PREFIX . "inferno_shout s
			LEFT JOIN " . TABLE_PREFIX . "inferno_user u
			ON s.uid = u.uid
			{$where}
			ORDER BY s.sid;
		");
		$result = $this->db->fetch_array($query);

		return ($result['total']) ? (int) $result['total'] : 0;
	}

	/**
	 * Render Select drop downs
	 *
	 * @param string $string Select Drop Down
	 * @return string
	 */
	public function render_select_box($string)
	{
		$array = $this->get_setting_array('shoutbox_' . $string);
		// $mouseover = 'onmouseover="javascript: inferno.update_entry_style(\'' . $string . '\', this.value); return false;"';
		$html = '<select id="inferno_' . $string . '" onchange="javascript: inferno.update_style(\'' . $string . '\', this); return false;">';
		$html .= '<option value="Default">Default</option>';
		$css = ($string == 'color') ? 'color' : 'font-family';
		$sel = "";

		foreach ($array as $val)
		{
			if(isset($this->userinfo[$string]))
			{
				$sel = (strtolower($this->userinfo[$string]) == strtolower($val)) ? 'selected="selected"' : '';
			}
			$html .= '<option style="' . $css . ':' . $val . ';" ' . $sel . '>' . $val . '</option>';
		}

		$html .= '</select>';

		return $html;
	}

	public function get_permissions($perm)
	{

		if('inferno_usergroups_'.$perm == -1)
		{
			return true;
		}
		else if('inferno_usergroups_'.$perm == "")
		{
			return false;
		}
		else
		{
			$group = $this->get_setting_array('usergroups_' . $perm, ',');
			if(is_array($group))
			{
				return (in_array($this->mybb->user['usergroup'], $group)) ? true : false;
			}
		}
	}

	/**
	 * Returns an aarray of a single setting
	 *
	 * @param string $setting Setting Name
	 * @return array
	 */
	public function get_setting_array($setting, $delimeter = "\r\n")
	{
		if(isset($this->settings['inferno_' . $setting]))
		{
			return explode($delimeter, $this->settings['inferno_' . $setting]);
		}
	}

	public function update_styles($array)
	{
		$uid = (int) $this->mybb->user['uid'];
		return $this->db->update_query('inferno_user', $array, "uid = '{$uid}'");
	}

	public function fetch_mybb_userinfo($user)
	{
		if (is_numeric($user))
		{
			if($user == 0)
			{
				$data = ['username' => $this->lang->guest, 'usergroup' => 1, 'displaygroup' => 1];
				return $data;
			}
			else
			{
				return get_user($user);
			}
		}
		else
		{
			$data = $this->db->escape_string($user);
			$query = $this->db->simple_select("users","*","username='{$data}'");
			return $this->db->fetch_array($query);
		}
	}

	public function toggle_ban($uid, $yesno)
	{
		$yesno = ($yesno) ? 1 : 0;

		$fromid = $this->mybb->user['uid'];
		$logger = $this->lang->shout_has . ((!$yesno) ? ' ' : '') . $this->lang->shout_banned_user . $uid;
		$this->log($logger);

		$query_update = $this->update_userinfo(array(
			'banned' => $yesno
		), $uid);

		$query_insert = $this->insert_bannedinfo(array(
			'ban_uid' => (int)$uid,
			'ban_by' => (int)$fromid,
			'ban_reason' => "Unknown",
		), $uid);		
		
		return $query_update.$query_insert;
	}

	public function toggle_ban_time($uid, $time, $reason, $yesno)
	{
		$yesno = ($yesno) ? 1 : 0;

		$fromid = $this->mybb->user['uid'];
		$time = (int)$time;
		if($time <= 0)
			exit;
		$logger = $this->lang->shout_has . ((!$yesno) ? ' ' : '') . $this->lang->shout_banned_user . $uid . " next " . $time . "hours, reason: ". $reason;
		$this->log($logger);

		$query_update = $this->update_userinfo(array(
			'banned' => $yesno
		), $uid);

		$query_insert = $this->insert_bannedinfo(array(
			'ban_uid' => (int)$uid,
			'ban_by' => (int)$fromid,
			'ban_reason' => $this->db->escape_string($reason),
			'ban_start' => time(),
			'ban_end' => time() + $time * 60 * 60 * 24
		), $uid);		
		
		return $query_update.$query_insert;
	}
	
	public function insert_bannedinfo($array, $uid = 0)
	{
		$uid = ($uid == 0) ? (int) $this->mybb->user['uid'] : (int) $uid;
		return $this->db->insert_query('inferno_banned_users', $array);
	}
	
	public function toggle_silence($uid, $yesno)
	{
		$yesno = ($yesno) ? 1 : 0;

		$logger = $this->lang->shout_have . ((!$yesno) ? ' ' : '') . $lang->shout_have_silenced . $uid;
		$this->log($logger);

		return $this->update_userinfo(array(
			'silenced' => $yesno
		), $uid);
	}

	public function update_userinfo($array, $uid = 0)
	{
		$uid = ($uid == 0) ? (int) $this->mybb->user['uid'] : (int) $uid;
		return $this->db->update_query('inferno_user', $array, "uid = '{$uid}'");
	}

	/**
	 * Gets user's Inferno Info
	 *
	 * @return void
	 */
	public function fetch_userinfo($uid = 0)
	{
		$uid = ($uid == 0) ? (int) $this->mybb->user['uid'] : (int) $uid;
		$query = $this->db->query("SELECT * FROM " . TABLE_PREFIX . "inferno_user WHERE uid='{$uid}'");
		$result = $this->db->fetch_array($query);

		if ($uid && !$result)
		{
			if ($this->fetch_mybb_userinfo($uid))
			{
				$this->create_user($uid);
				return $this->fetch_userinfo($uid);
			}
		}

		return ($result) ? $result : false;
	}

	public function create_user($uid)
	{
		return $this->db->insert_query('inferno_user', array(
			'uid' => $uid
		));
	}

	public function delete_user($uid)
	{
		$q1 = $this->db->delete_query("inferno_user", "uid='{$uid}'");
		$q2 = $this->db->delete_query("inferno_shout", "uid='{$uid}'");
		return ($q1 && $q2);
	}

	public function gen_banlist()
	{
		$query = $this->db->query("SELECT * FROM " . TABLE_PREFIX . "inferno_user WHERE banned=1");
		$users = array();
		while ($row = $this->db->fetch_array($query))
		{
			$u = $this->fetch_mybb_userinfo($row['uid']);
			$users[] = $u['username'];
		}
		if (empty($users))
		{
			return $this->lang->sprintf($this->lang->isb_list_empty, strtolower($this->lang->isb_banned));
		}
		return $this->lang->sprintf($this->lang->isb_list, strtolower($this->lang->isb_banned), implode(', ', $users));
	}
	
	public function gen_silencelist()
	{
		$query = $this->db->query("SELECT * FROM " . TABLE_PREFIX . "inferno_user WHERE silenced=1");
		$users = array();

		while ($row = $this->db->fetch_array($query))
		{
			$u = $this->fetch_mybb_userinfo($row['uid']);
			$users[] = $u['username'];
		}

		if (empty($users))
		{
			return $this->lang->sprintf($this->lang->isb_list_empty, strtolower($this->lang->isb_silenced));
		}
		return $this->lang->sprintf($this->lang->isb_list, strtolower($this->lang->isb_silenced), implode(', ', $users));
	}

	public function log($string)
	{
		$log_entry = array(
			'uid' => $this->mybb->user['uid'],
			'ipaddress' => $this->db->escape_string(get_ip()),
			'dateline' => TIME_NOW,
			'fid' => '0',
			'tid' => '0',
			'pid' => '0',
			'action' => $this->db->escape_string($string),
			'data' => 'a:0:{}' // the fuk is this chit? $this->db->escape_string(@serialize($data))
		);

		$this->db->insert_query('moderatorlog', $log_entry);
	}

	/**
	 * Install the Inferno Shoutbox
	 *
	 * @return void
	 */
	public function install()
	{
		$query = $this->db->simple_select("settinggroups", "COUNT(*) as gids");
		$gid = $this->db->fetch_field($query, "gids");
		// Create Setting Group
		$this->db->insert_query('settinggroups', array(
			'name' 			=> 'inferno',
			'title' 		=> 'Inferno Shoutbox Options',
			'description' 	=> 'This section allows you to manage the various settings of your Inferno Shoutbox.',
			'disporder'		=> (int)$gid,			
			'isdefault' 	=> 0
		));

		// Populate Settings
		$settings = array(
			array(
				'name' 			=> 'enabled',
				'title' 		=> 'Shoutbox Online',
				'description' 	=> 'Is the shoutbox system online?',
				'optionscode' 	=> 'onoff',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'shoutbox_title',
				'title' 		=> 'Shoutbox Title',
				'description' 	=> 'The shoutbox title displayed on the category row of the shoutbox on your forums.',
				'optionscode' 	=> 'text',
				'value' 		=> trim($this->db->escape_string($this->settings['bbname']) . ' Shoutbox')
			),
			array(
				'name' 			=> 'shoutbox_anus',
				'title' 		=> 'Shoutbox ANUS (Advanced Network Updating System)',
				'description' 	=> 'ANUS (Advanced Network Updating System) is a feature that greatly reduces the resources consumed by the shoutbox, which is ideal for small servers, or sites that wish to optimize the shoutbox. 
				<br />Turning this feature on will ensure the shoutbox only requests data when there is new data to be displayed
				<br />Note: Turning this option on may create a half or one second delay in displaying new shouts.',
				'optionscode' 	=> 'onoff',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'shoutbox_pm',
				'title' 		=> 'Enable Private Messaging System',
				'description' 	=> 'Set to "Off" to disable the shoutbox private messaging system.',
				'optionscode' 	=> 'onoff',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'minimum_posts',
				'title' 		=> 'Minimum Posts to View Shoutbox',
				'description' 	=> 'Enter the number of posts a user must have before they can participate in the shoutbox.
				<br />Leave blank to disable',
				'optionscode' 	=> 'text',
				'value' 		=> ''
			),
			array(
				'name' 			=> 'alert_admincommands',
				'title' 		=> 'Disable Admin Command Notices',
				'description' 	=> 'Switching this setting to Yes will mean that when an admin executes a command in the shoutbox (such as pruning, or banning a user) the notice that usually automatically shows will not be shown.',
				'optionscode' 	=> 'yesno',
				'value' 		=> '0'
			),
			array(
				'name' 			=> 'shouts_display',
				'title' 		=> 'Shouts To Display',
				'description' 	=> 'Select the number of shouts you wish to display within the shoutbox.
				<br />Note: the higher this number, the more intensive the shoutbox may be on your server.',
				'optionscode' 	=> 'text',
				'value' 		=> '25'
			),
			array(
				'name' 			=> 'shout_order',
				'title' 		=> 'Shout Display Order',
				'description' 	=> 'Select \"on\" to display shouts in descending order. Select \"off\" to display shouts in ascending order.',
				'optionscode' 	=> 'onoff',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'avatars',
				'title' 		=> 'Display User Avatars',
				'description' 	=> 'Enter a number in pixels to enable. This number will set the width and height of the avatar in each shout.
				<br>For example, setting this field to \"50\" will display each avatar and make the width=\"50\" and height=\"50\".
				<br>To disable this feature, keep this field empty',
				'optionscode' 	=> 'text',
				'value' 		=> '19'
			),
			array(
				'name' 			=> 'shoutbox_flood',
				'title' 		=> 'Flood Control',
				'description' 	=> 'Set how many seconds a user must wait before posting another shout after a previous.
				<br />For example, if this was set to 3, and a user made a shout, they would only be able to shout again 3 seconds later.',
				'optionscode' 	=> 'text',
				'value' 		=> '5'
			),
			array(
				'name' 			=> 'shoutbox_color',
				'title' 		=> 'Editor Colors',
				'description' 	=> 'You may customize the colors automatically shown in the shoutbox editor for people to pick for the messages they shout.
				<br />Put one color on each line and make sure you only use hexcodes or color names.',
				'optionscode' 	=> 'textarea',
				'value' 		=> 'Red\r\nBlue\r\nGreen\r\nOrange\r\nBrown\r\nBlack\r\nYellow\r\nPurple\r\nPink\r\nSilver'
			),
			array(
				'name' 			=> 'shoutbox_font',
				'title' 		=> 'Editor Fonts',
				'description' 	=> 'Similar to "Editor Colors", only this applies for font styles.',
				'optionscode' 	=> 'textarea',
				'value' 		=> 'Arial\r\nArial Black\r\nArial Narrow\r\nBook Antiqua\r\nCentury Gothic\r\nComic Sans MS\r\nCourier New\r\nFixedsys\r\nFranklin Gothic Medium\r\nGaramond\r\nGeorgia\r\nImpact\r\nLucida Console\r\nMicrosoft Sans Serif\r\nPalatino Linotype\r\nSystem\r\nTahoma\r\nTimes New Roman\r\nTrebuchet MS\r\nVerdana'
			),
			array(
				'name' 			=> 'css_height',
				'title' 		=> 'Default Shoutbox Window Height',
				'description' 	=> 'Specify a number in pixels for the default height of the window where shouts will be displayed. You do not need to enter "px".',
				'optionscode' 	=> 'text',
				'value' 		=> '250'
			),
			array(
				'name' 			=> 'button_bold',
				'title' 		=> 'Show Bold Button',
				'description' 	=> 'Specify if the bold button will be displayed within the shoutbox editor.',
				'optionscode' 	=> 'yesno',
				'value' 		=> '0'
			),
			array(
				'name' 			=> 'button_underline',
				'title' 		=> 'Show Underline Button',
				'description' 	=> 'Specify if the underline button will be displayed within the shoutbox editor.',
				'optionscode' 	=> 'yesno',
				'value' 		=> '0'
			),
			array(
				'name' 			=> 'button_italic',
				'title' 		=> 'Show Italic Button',
				'description' 	=> 'Specify if the italic button will be displayed within the shoutbox editor.',
				'optionscode' 	=> 'yesno',
				'value' 		=> '0'
			),
			array(
				'name' 			=> 'button_colors',
				'title' 		=> 'Show Colors Drop-Down',
				'description' 	=> 'Specify if the colors drop-down will be displayed within the shoutbox editor.',
				'optionscode' 	=> 'yesno',
				'value' 		=> '0'
			),
			array(
				'name' 			=> 'button_fonts',
				'title' 		=> 'Show Fonts Drop-Down',
				'description' 	=> 'Specify if the fonts drop-down will be displayed within the shoutbox editor.',
				'optionscode' 	=> 'yesno',
				'value' 		=> '0'
			),
			array(
				'name' 			=> 'button_smilies',
				'title' 		=> 'Show Smilies Button',
				'description' 	=> 'Specify if the smilies button will be displayed within the shoutbox editor.',
				'optionscode' 	=> 'yesno',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'shoutbox_notice',
				'title' 		=> 'Shoutbox Notice',
				'description' 	=> 'This will be displayed above all shouts and remain static. Leave blank for no notice. You can either enter the notice here or use the following commands within the shoutbox:
				<pre>/notice [your message here]\n/removenotice</pre>',
				'optionscode' 	=> 'text',
				'value' 		=> ''
			),
			array(
				'name' 			=> 'usergroups_admin',
				'title' 		=> 'Administrator Usergroups',
				'description' 	=> 'Note any usergroups here that will have administrator commands.
				<br />Seperate each group with a comma',
				'optionscode' 	=> 'text',
				'value' 		=> '4'
			),
			array(
				'name' 			=> 'usergroups_mod',
				'title' 		=> 'Moderator Usergroups',
				'description' 	=> 'Note any usergroups here that will have moderator commands.
				<br />Seperate each group with a comma',
				'optionscode' 	=> 'groupselect',
				'value' 		=> '3,6'
			),
			array(
				'name' 			=> 'usergroups_protected',
				'title' 		=> 'Protected Usergroups',
				'description' 	=> 'Note any usergroups here to be protected, they will not be allowed to be banned, silenced, etc.
				<br />Seperate each group with a comma',
				'optionscode' 	=> 'groupselect',
				'value' 		=> '4'
			),
			array(
				'name' 			=> 'usergroups_banned',
				'title' 		=> 'Banned Usergroups',
				'description' 	=> 'Select the usergroups that are banned from the shoutbox. Users in these groups will not be able to see or access the shoutbox.
				<br />Seperate each group with a comma',
				'optionscode' 	=> 'groupselect',
				'value' 		=> '1,5,7'
			),
			array(
				'name' 			=> 'js_refresh',
				'title' 		=> 'Shoutbox Refresh Rate',
				'description' 	=> 'Enter the amount in seconds before the shoutbox updates.
				<br />When a user is not idle within the shoutbox, AJAX will dynamically refresh the shoutbox to fetch new content, the faster this is, the more real time the shoutbox is. However, this speed comes at the cost of your system resources, and depending on your server/forum activity, it may be a very bad idea to set this to a low number.
				<br />To get the best results, I recommend testing new settings here, pushing time in small amounts (recommended: 1 second) and see what impact that makes on your server load.',
				'optionscode' 	=> 'text',
				'value' 		=> '20'
			),
			array(
				'name' 			=> 'idle_timeout',
				'title' 		=> 'Shoutbox Idle Timeout',
				'description' 	=> 'Enter the amount (in minutes) before a user will becomde idle client side due to inactivity. Default is 10 minutes
				<br />Note: When a user is idle, it will no longer refresh the shoutbox until they choose to un-idle.',
				'optionscode' 	=> 'text',
				'value' 		=> '10'
			),
			array(
				'name' 			=> 'shout_max_chars',
				'title' 		=> 'Maximum Shout Length',
				'description' 	=> 'The maximum amount of characters allowed in a single shout.',
				'optionscode' 	=> 'text',
				'value' 		=> '350'
			),
			array(
				'name' 			=> 'thread_post',
				'title' 		=> 'New Thread Shout',
				'description' 	=> 'Select "Yes" to automatically have a shout posted when a user posts a new thread.',
				'optionscode' 	=> 'yesno',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'thread_forums',
				'title' 		=> 'New Thread Shout Exempt Forums',
				'description' 	=> 'Enter the ID for each forum that will NOT have a shout automatically posted when a user posts a new thread. Enter secret forums such as staff sections, 18+, etc.
				<br />Seperate each forum ID with a comma',
				'optionscode' 	=> 'text',
				'value' 		=> ''
			),
			array(
				'name' 			=> 'newpost',
				'title' 		=> 'Post Count Shout',
				'description' 	=> 'Have the shoutbox post a shout every time a user hits X number of posts.
				<br />For example: 100 would post a shout every 100, 200, 300... posts a user makes.
				<br />Leave blank to disable this feature',
				'optionscode' 	=> 'text',
				'value' 		=> '100'
			),
			array(
				'name' 			=> 'shoutbox_cutoff',
				'title' 		=> 'Shoutbox Cutoff Time',
				'description' 	=> 'You can customize how long a user is displayed as "active" in the "Active Users Tab" here. Default is 10 minutes.',
				'optionscode' 	=> 'text',
				'value' 		=> '10'
			),
			array(
				'name' 			=> 'smilies',
				'title' 		=> 'Allow Smilies',
				'description' 	=> 'Select "On" if you would like to allow users to use smilies within shout messages.',
				'optionscode' 	=> 'yesno',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'smilies_limit',
				'title' 		=> 'Smiley Display Limit',
				'description' 	=> 'Enter the maximum number of smilies to display when a person clicks the "Smilies" button
				<br />Enter 0 to disable',
				'optionscode' 	=> 'text',
				'value' 		=> '0'
			),
			array(
				'name' 			=> 'shout_markup',
				'title' 		=> 'Markup Shouts',
				'description' 	=> 'Select "On" to display user set bold, italic, underline, colors, and fonts in user shouts.',
				'optionscode' 	=> 'onoff',
				'value' 		=> '0'
			),
			array(
				'name' 			=> 'allow_mycode',
				'title' 		=> 'Enable MyCode',
				'description' 	=> 'Select "On" to parse all MyCode in user shouts.',
				'optionscode' 	=> 'onoff',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'banned_mycode',
				'title' 		=> 'Banned MyCode',
				'description' 	=> 'Enter the mycode tags that users will NOT be allowed to use. Administrators can still use banned MyCode
				<br > Seperate each mycode with a comma',
				'optionscode' 	=> 'text',
				'value' 		=> 'php,code,quote,img,list,size'
			),
			array(
				'name' 			=> 'filter_badwords',
				'title' 		=> 'Filter Bad Words',
				'description' 	=> 'Select "On" to automatically censor bad words (based on your forum&#39;s filter) in shouts.',
				'optionscode' 	=> 'onoff',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'archive',
				'title' 		=> 'Archive Online',
				'description' 	=> 'Is the shoutbox archive system online?',
				'optionscode' 	=> 'onoff',
				'value' 		=> '1'
			),
			array(
				'name' 			=> 'archive_shouts_per_page',
				'title' 		=> 'Archive: Shouts Per Page',
				'description' 	=> 'Enter the number of shouts you want to be displayed per page of the archive.',
				'optionscode' 	=> 'text',
				'value' 		=> '50'
			),
			array(
				'name' 			=> 'parse_youtube_videos',
				'title' 		=> 'Parse youtube links by api source',
				'description' 	=> 'Parse youtube links inside shoutbox (Consume more api resources and maybe do not load sometimes). Otherwise links are inserted into shout sent saving into database all data to retrieve information fast and saving api resource data loading all times',
				'optionscode' 	=> 'yesno',
				'value' 		=> 'no'
			),			
			array(
				'name' 			=> 'shoutbox_youtube_api',
				'title' 		=> 'Your API from Youtube',
				'description' 	=> 'Enter your API obtained into your google account for youtube developers api key',
				'optionscode' 	=> 'text',
				'value' 		=> ''
			),
			array(
				'name' 			=> 'shoutbox_chatbot_enabled',
				'title' 		=> 'Shows Chatbot instead username for command lines and posts, thread creation?',
				'description' 	=> 'Set to yes if you like to not show user command lines and posts, threads, deletes, bans, etc. (By default show username)',
				'optionscode' 	=> 'yesno',
				'value' 		=> 'no'
			),
			array(
				'name' 			=> 'shoutbox_detailed_info',
				'title' 		=> 'Shoutbox Thread detailed information on thread creation (forums where is created)',
				'description' 	=> 'Set to no to use traditional only link to thread creation, otherwise more data are retrieved',
				'optionscode' 	=> 'yesno',
				'value' 		=> 'no'
			),
			array(
				'name' 			=> 'shoutbox_postnum',
				'title' 		=> 'To use the shoutbox requires post count put 0 to disable feature (Not applicable for admins)',
				'description' 	=> 'Set the number of posts that users must have to use the shoutbox (Less values just can see shoutbox)',
				'optionscode' 	=> 'numeric',
				'value' 		=> '0'
			)				
		);

		$sgid = $this->db->insert_id();

		// Insert Settings
		for ($i = 0; $i < count($settings); $i++)
		{
			$settings[$i]['sid'] = '0';
			$settings[$i]['name'] = 'inferno_' . $settings[$i]['name'];
			$settings[$i]['disporder'] = ($i + 1);
			$settings[$i]['isdefault'] = '1';
			$settings[$i]['gid'] = $sgid;

			// debug
			if ($this->debug)
			{
				$settings[$i]['title'] .= ' | $settings[\\\'' . $settings[$i]['name'] . '\\\']';
			}

			$this->db->insert_query('settings', $settings[$i]);
		}

		rebuild_settings();
		
		// Insert Shoutbox Tables
		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . TABLE_PREFIX ."inferno_shout` (
			  `sid` int(11) NOT NULL AUTO_INCREMENT,
			  `uid` int(11) NOT NULL DEFAULT '0',
			  `shout` longtext NOT NULL,
			  `me` tinyint(1) NOT NULL DEFAULT '0',
			  `is_read` tinyint(1) NOT NULL DEFAULT '0',
			  `whisper` int(11) NOT NULL DEFAULT '0',			  
			  `private` int(11) NOT NULL DEFAULT '0',
			  `timestamp` int(10) NOT NULL DEFAULT '0',
			  PRIMARY KEY (`sid`)
			) DEFAULT CHARSET=utf8;
		");

		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . TABLE_PREFIX ."inferno_user` (
			  `pid` int(11) NOT NULL AUTO_INCREMENT,
			  `uid` int(11) NOT NULL DEFAULT '0',
			  `bold` tinyint(1) NOT NULL DEFAULT '0',
			  `italic` tinyint(1) NOT NULL DEFAULT '0',
			  `underline` tinyint(1) NOT NULL DEFAULT '0',
			  `color` varchar(100) NOT NULL DEFAULT '',
			  `font` varchar(100) NOT NULL DEFAULT '',
			  `banned` tinyint(1) NOT NULL DEFAULT '0',
			  `silenced` tinyint(1) NOT NULL DEFAULT '0',
			  `ban_votes` tinyint(4) NOT NULL DEFAULT '0',
			  `ban_votes_add` tinyint(1) NOT NULL DEFAULT '0',	
			  `twich_votes_add` tinyint(1) NOT NULL DEFAULT '0',		  
			  `whispers` tinyint(4) NOT NULL DEFAULT '0',
			  `unread_pms` tinyint(4) NOT NULL DEFAULT '0',
			  `is_online` tinyint(1) NOT NULL DEFAULT '0',			  
			  `dateline` int(10) NOT NULL DEFAULT '0',
			  PRIMARY KEY (`pid`)
			) DEFAULT CHARSET=utf8;
		");

		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . TABLE_PREFIX ."inferno_banned_users` (
			  `ban_id` int(11) NOT NULL AUTO_INCREMENT,		
			  `ban_uid` int(11) NOT NULL DEFAULT '0',	  
			  `ban_start` int(10) NOT NULL DEFAULT '0',
			  `ban_end` int(10) NOT NULL DEFAULT '0',			  
			  `ban_reason` varchar(100) NOT NULL DEFAULT '',
			  `ban_by` int(11) NOT NULL DEFAULT '0',		  
			  PRIMARY KEY (`ban_id`)
			) DEFAULT CHARSET=utf8;
		");

		$install_shouts = array(
			'Congratulations! Your copy of Inferno Shoutbox ' . $this->version . ' has been installed successfully!',
			'Shoutbox settings can be found at Admin CP -> Configuration -> Inferno Shoutbox Options',
			'Command names can be modified to your liking in the Inferno language file',
			'View the Archive by clicking the Shoutbox Title',
			'Double click a shout to edit or delete it',
			'Erase these shouts by typing /prune',
			'Go to read command list by typing /help'
		);		

		foreach ($install_shouts as $s)
		{
			$this->create_shout($this->mybb->user['uid'], $s);
		}
	}

	public function is_installed()
	{
		return ($this->db->table_exists('inferno_shout')||$this->db->table_exists('inferno_user')) ? true : false;
	}

	public function activate()
	{
		if(!$this->db->field_exists("is_read", "inferno_shout"))
		{
			$this->db->write_query("ALTER TABLE `".TABLE_PREFIX."inferno_shout` ADD `is_read` tinyint(1) NOT NULL DEFAULT '0'");
		}
		if(!$this->db->field_exists("whisper", "inferno_shout"))
		{
			$this->db->write_query("ALTER TABLE `".TABLE_PREFIX."inferno_shout` ADD `whisper` int(11) NOT NULL DEFAULT '0'");
		}
		if(!$this->db->field_exists("ban_votes", "inferno_user"))
		{
			$this->db->write_query("ALTER TABLE `".TABLE_PREFIX."inferno_user` ADD `ban_votes` tinyint(4) NOT NULL DEFAULT '0'");
		}
		if(!$this->db->field_exists("ban_votes_add", "inferno_user"))
		{
			$this->db->write_query("ALTER TABLE `".TABLE_PREFIX."inferno_user` ADD `ban_votes_add` tinyint(1) NOT NULL DEFAULT '0'");
		}		
		if(!$this->db->field_exists("twich_votes_add", "inferno_user"))
		{
			$this->db->write_query("ALTER TABLE `".TABLE_PREFIX."inferno_user` ADD `twich_votes_add` tinyint(1) NOT NULL DEFAULT '0'");
		}				
		if(!$this->db->field_exists("whispers", "inferno_user"))
		{
			$this->db->write_query("ALTER TABLE `".TABLE_PREFIX."inferno_user` ADD `whispers` tinyint(4) NOT NULL DEFAULT '0'");
		}
		if(!$this->db->field_exists("unread_pms", "inferno_user"))
		{
			$this->db->write_query("ALTER TABLE `".TABLE_PREFIX."inferno_user` ADD `unread_pms` tinyint(4) NOT NULL DEFAULT '0'");
		}
		if(!$this->db->field_exists("is_online", "inferno_user"))
		{
			$this->db->write_query("ALTER TABLE `".TABLE_PREFIX."inferno_user` ADD `is_online` tinyint(1) NOT NULL DEFAULT '0'");
		}		

		$stylecss = ".inferno_table{position: relative;z-index:1}
.inferno_table select{border:1px solid #ccc;border-radius:3px 3px 3px 3px;color:#000;font:11px Tahoma,Calibri,Verdana,Geneva,sans-serif;outline:0 none;padding:4px}
.inferno_text{width: 99%;border: 1px solid #ccc;height: 32px;border-radius: 4px;font-size:14px}
.inferno_shoutbox{font-size:12px}
.inferno_content{padding-left:0px;word-wrap:break-word;margin-right:5px;margin-bottom:20px;margin-top:5px;overflow:auto;margin-left:0px;padding-right:10px}
.inferno_content a{text-decoration:none;padding:0 2px}
.inferno_content a:hover{text-decoration:underline}
.inferno_content img{max-width: 80px; max-height: 80px}
.inferno_content iframe{width: 120px; height: 120px}
.inferno_buttons_icons{cursor:pointer;padding: 2px}
.inferno_alert{background-color:#FBEF8D;padding:1px}
.inferno_alert_div{padding:8px 0px 3px 5px}
.items{background:#f0f0f0;color:#454242}
.sbcount {width: 188px;height: auto;color: #454242;background: #fff;border-radius: 2px;margin: auto;opacity: 0.9;padding: 0;position: absolute;list-style: none;display: none;text-align: center;line-height: 30px;z-index:9}
.sbcount li {display: block;border-bottom: 1px dotted #958d8d;width: 188px}
.shout_pm,.shout_mine,.shout_user,.shout_private{width: 185px;display:inline-block;vertical-align: top;white-space:nowrap;padding-left:0px}
.shout_pm a,.shout_mine a,.shout_user a,.shout_private a{color: #086}
.inferno_separator{width: 25px;display:inline-block;vertical-align: top}
.chat_normal_shout,.chat_pm_shout{display:inline-block;vertical-align: top;word-wrap: break-word;width: 55%}
.chat_avatar{margin: 0px -1px -5px 0px;border-radius: 50%;width: 19px;height: 19px}
.chat_date_shout{width: 70px;float:right;text-align: right}
.chat_controls{width: 80px;float:right;display:inline-block;vertical-align: top;text-align: right}
.sb_shouts{display:inline-block;padding: 5px 0px 5px 0px;border-bottom: 1px solid #cacaca;width:100%}
.sb_shouts:hover{background: #cacaca}
.shoutbox_avatar_letter{font-weight: 700;width: 19px;height: 19px;border-radius: 50%;font-size: 10px;line-height: 18px;box-sizing: content-box;color: #FFF;text-align: center;vertical-align: top;display: inline-block;text-transform: uppercase;margin: 0px -1px -5px 0px}
.inferno_alert_error{text-align: center;background: #f6de30;border-radius: 2px;height: 25px;border: 1px solid #d7a911;font-weight: bold;line-height: 22px;color: #404139;opacity:0.8}
@media only screen and (min-device-width:320px) and (max-device-width:550px){
	#bannedlist,#postshout,#buttonclear,#smiliesbutton,#inferno_links,.chat_date_shout,.chat_controls{display:none}
}";

		$query = $this->db->simple_select('themes', 'tid');
		while($theme = $this->db->fetch_array($query))
		{
			$stylesheet = array(
				"name"			=> "inferno.css",
				"tid"			=> (int) $theme['tid'],
				"attachedto"	=> "",
				"stylesheet"	=> $this->db->escape_string($stylecss),
				"cachefile"		=> "inferno.css",
				"lastmodified"	=> TIME_NOW
			);

			$sid = $this->db->insert_query("themestylesheets", $stylesheet);
			require_once MYBB_ADMIN_DIR.'/inc/functions_themes.php';
			cache_stylesheet($stylesheet['tid'], $stylesheet['cachefile'], $stylecss);
			update_theme_stylesheet_list(1, false, true);		
	
		}

		$inferno_templates = array(
			array(
				'title' => 'inferno_shoutbox',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/shoutbox.html')
			),
			array(
				'title' => 'inferno_archive',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/archive.html')
			),
			array(
				'title' => 'inferno_archive_table',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/archive_table.html')
			),
			array(
				'title' => 'inferno_banned_list',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/banned_list.html')
			),
			array(
				'title' => 'inferno_banned_list_rows',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/banned_list_rows.html')
			),			
			array(
				'title' => 'inferno_banned_list_modal',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/banned_list_modal.html')
			),
			array(
				'title' => 'inferno_banned_list_modal_rows',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/banned_list_modal_rows.html')
			),
			array(
				'title' => 'inferno_modal_user',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/modal_user.html')
			),
			array(
				'title' => 'inferno_twitch_enabled',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/twitch_enabled.html')
			),
			array(
				'title' => 'inferno_twitch_disabled',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/twitch_disabled.html')
			),
			array(
				'title' => 'inferno_vote_ban_enabled',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/vote_ban_enabled.html')
			),
			array(
				'title' => 'inferno_vote_ban_disabled',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/vote_ban_disabled.html')
			),
			array(
				'title' => 'inferno_edit_buttons',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/edit_buttons.html')
			),
			array(
				'title' => 'inferno_edit_buttons_admin',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/edit_buttons_admin.html')
			),
			array(
				'title' => 'inferno_chatbot_enabled',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/chatbot_enabled.html')
			),
			array(
				'title' => 'inferno_chatbot_disabled',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/chatbot_disabled.html')
			),
			array(
				'title' => 'inferno_pm_shout',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/pm_shout.html')
			),
			array(
				'title' => 'inferno_whisper_shout',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/whisper_shout.html')
			),
			array(
				'title' => 'inferno_normal_shout_mine',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/normal_shout_mine.html')
			),
			array(
				'title' => 'inferno_normal_shout',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/normal_shout.html')
			),
			array(
				'title' => 'inferno_delete_shout',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/delete_shout.html')
			),
			array(
				'title' => 'inferno_pm_shout_mine',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/pm_shout_mine.html')
			),
			array(
				'title' => 'inferno_admin_commands',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/admin_commands.html')
			),
			array(
				'title' => 'inferno_notice',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/notice.html')
			),
			array(
				'title' => 'inferno_whispers_remove',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/whispers_remove.html')
			),
			array(
				'title' => 'inferno_whispers_shout',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/whispers_shout.html')
			),
			array(
				'title' => 'inferno_container',
				'template' => file_get_contents(MYBB_ROOT . 'inc/plugins/inferno/templates/container.html')
			)
		);

		foreach ($inferno_templates as $t)
		{
			$t['dateline'] = TIME_NOW;
			$t['sid'] = '-2';
			$t['version'] = '1800';
			$t['template'] = $this->db->escape_string($t['template']);
			$this->db->insert_query('templates', $t);
		}

		$inferno_templates = [];

		$inferno_tg = array(
			"prefix"	=> 'inferno',
			"title"		=> 'Inferno Shoutbox',
		);

		$this->db->insert_query('templategroups', $inferno_tg);
		
		require_once MYBB_ROOT . '/inc/adminfunctions_templates.php';
		find_replace_templatesets('index', '#' . preg_quote('{$forums}') . '#', '{$inferno_shoutbox}{$forums}');
	}

	public function deactivate()
	{
		$this->db->delete_query("templategroups", "prefix = 'inferno';");
		$this->db->delete_query("templates", "title LIKE 'inferno_%';");
	  	$this->db->delete_query('themestylesheets', "name='inferno.css'");
		$query = $this->db->simple_select('themes', 'tid');
		while($theme = $this->db->fetch_array($query))
		{
			require_once MYBB_ADMIN_DIR.'inc/functions_themes.php';
			update_theme_stylesheet_list($theme['tid']);
		}
		require_once MYBB_ROOT . '/inc/adminfunctions_templates.php';
		find_replace_templatesets('index', '#' . preg_quote('{$inferno_shoutbox}') . '#', '');
	}

	public function please_support_the_developer(&$footer)
	{
		$string = 'Inferno Shoutbox v' . $this->version;
	}

	public function uninstall()
	{
		// Delete all tables & Info!
		$this->db->delete_query("settinggroups", "name = 'inferno';");
		$this->db->delete_query("settings", "name LIKE 'inferno_%';");
		rebuild_settings();
		$this->db->query("DROP TABLE IF EXISTS " . TABLE_PREFIX . "inferno_shout");
		$this->db->query("DROP TABLE IF EXISTS " . TABLE_PREFIX . "inferno_user");
		$this->db->query("DROP TABLE IF EXISTS " . TABLE_PREFIX . "inferno_banned_users");
	}
}
