<?php
$inferno_config = array(
	'twich_mode' => 1,
	'twich_mode_total' => 0,
	'twich_mode_count' => 0,	
	'vote_ban' => 0,
	'vote_ban_total' => 0
);