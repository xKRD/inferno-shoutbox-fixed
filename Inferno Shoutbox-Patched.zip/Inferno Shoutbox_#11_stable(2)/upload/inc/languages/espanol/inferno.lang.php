<?php

/**
 * Inferno Shoutbox Paquete de Idioma Español por Dark Neo
 *  
 */

############ MAIN ############

// Main Shoutbox
$l['isb_shoutboxtab'] 		= 'Chat';
$l['isb_activetab']   		= 'Usuarios activos';
$l['isb_activeusers'] 		= 'Actualmente hay {1} usuario(s) en línea';

$l['isb_btn_shout'] 		= 'Enviar';
$l['isb_btn_clear'] 		= 'Limpiar';
$l['isb_btn_smilies']		= 'Caritas';

// Archive
$l['isb_archive']			= 'Archivo';
$l['isb_archive_dt']		= 'Archivo deshabilitado';
$l['isb_archive_noview']	= 'No tienes permisos para ver el archivo.';
$l['isb_archive_disabled']	= 'El archivo ha sido deshabilitado por un administrador.';
$l['isb_archive_page']		= 'Página';
$l['isb_archive_btn_go']	= 'Ir';

// Auto-Messages
$l['isb_newthread']			= 'ha creado el nuevo tema: {1}';
$l['isb_newpost']			= 'ha creado el mensaje : {1}';
$l['isb_newpost_reach']			= 'a alcanzado los {1} mensajes';

############ SHOUTBOX COMMANDS ############ 

/*
	Each command is grouped with the message it displays (if applicable) when the command is executed
	
	Each command has the language prefix: isb_c_ 
	(stands for infernoshoutbox_command_)

	Example: 

	Changing

	$l['isb_c_me'] = 'me';

	TO

	$l['isb_c_me'] = 'mycommand';

	Will change the "/me" command syntax to "/mycommand".

*/

// Me
$l['isb_c_me']				= 'me';

// PM
$l['isb_c_pm']				= 'pm';

// Whisper
$l['isb_c_whisper']			= 'whisper';

// Notice
$l['isb_c_notice']			= 'notice';
$l['isb_c_notice_msg']		= '¡Noticia del Chat! : {1}';
$l['isb_c_removenotice']	= 'removenotice';

// General terms
$l['isb_banned']			= 'Bloqueado';
$l['isb_banned_sb']			= 'Has sido bloqueado de {1}.';
$l['isb_silenced']			= 'Silenciado';

// Show lists
$l['isb_c_banlist']			= 'banlist';
$l['isb_c_silencelist']		= 'silencelist';
$l['isb_list']				= 'Actualmente hay {1} Usuarios: {2}.';
$l['isb_list_empty']		= 'Actualmente no hay usuarios {1}.';

// Ban
$l['isb_c_ban']				= 'ban';
$l['isb_c_unban']			= 'unban';
$l['isb_ban_msg']			= 'se ha bloqueado a {1} del chat!';
$l['isb_unban_msg']			= 'se ha desbloqueado a {1} del chat!';
$l['isb_ban_msg_time_rea']  = 'se ha bloqueado a {1} del chat [Razón] {3} [Días bloqueado] {2} ';		

//Full ban (Debes agregar la id de usuario, días que se va a bloquear al usuario(1,31,etc) y la razón del bloqueo, sepárados por ;)
$l['isb_c_ban_full']		= 'fullban';

// Silence	
$l['isb_c_silence']			= 'silence';
$l['isb_c_unsilence']		= 'unsilence';
$l['isb_silence_msg']		= 'se ha silenciado a {1} en el chat!';
$l['isb_unsilence_msg']		= 'se ha desilenciado a {1} en el chat!';

// Prune	
$l['isb_c_prune']			= 'prune';
$l['isb_prune_msg']			= 'ha limpiado el chat!';
$l['isb_prune_user_msg']	= 'ha eliminado todos los mensajes de {1}!';
$l['isb_prune_days_msg']	= 'ha eliminado los mensajes de lo últimos {1} días!';

// Say	
$l['isb_c_say']				= 'say';

// Protected User
$l['isb_protected']			= 'El usuario "{1}" está protegido.';
// User doesn't exist
$l['isb_not_exists']		= 'El usuario "{1}" no existe.';
// User already banned
$l['isb_already_banned']	= 'El usuario "{1}" actualmente esta bloqueado.';

$l['isb_twitch_mode_cmd'] = "TwitchMode";
$l['isb_twitch_mode_votes'] = "TwitchModeVotes";
$l['isb_twitch_mode_enable_cmd'] = "TwitchModeOn";
$l['isb_twitch_mode_disable_cmd'] = "TwitchModeOff";
$l['isb_vote_ban_enable_cmd'] = "VoteBanOn";
$l['isb_vote_ban_disable_cmd'] = "VoteBanOff";
$l['isb_vote_ban_total_cmd'] = "VoteBanTotal";
$l['isb_vote_ban_cmd'] = "VoteBan";
## CHAT MESSAGES ##

$l['shout_pruned'] = "Ha limpiado todos los mensajes del usuario con ID: {1}";
$l['shout_cleaned'] = "Ha limpiado todo el chat";
$l['shout_deleted'] = "Eliminar mensaje por (ID Usuario: {1}) (ID Mensaje: {2})";
$l['shout_has'] = "Has ";
$l['shout_banned_user'] = "bloqueado al usuario con la ID: ";
$l['shout_have'] = "Tiene ";
$l['shout_have_silenced'] = "callado al usuario con la ID: "; 
$l['shout_installed1'] = 'Felicidades! Su copia de Inferno Shoutbox v {1} ha sido instalada correctamente!';
$l['shout_installed2'] = 'Los ajustes de este chat pueden encontrarse en Panel de Administrador -> Configuración -> Inferno Shoutbox Options';
$l['shout_installed3'] = 'La lista de comandos del chat pueden cambiarse en los archivos de idioma del chat Inferno';
$l['shout_installed4'] = 'Para ver el archivo de mensajes de chat de clic en el título de su chat';
$l['shout_installed5'] = 'Limpie todos los mensajes escribiendo /prune';
$l['shout_installed6'] = 'De doble clic en un mensaje para editarlo o eliminarlo';
$l['shout_private_disabled'] = "Los mensajes privados no estan habilitados.";
$l['isb_no_activeusers'] = "Actualmente no hay usuarios en linea.";
$l['no_private_start'] = '<i>No hay nada ';
$l['no_private_text'] = 'privados';
$l['no_private_end'] = ' para mostrar...</i>';

## JAVASCRIPT REFERENCES ##

$l['isb_cancel'] = "Cancelar";
$l['isb_delete'] = "Eliminar";
$l['isb_update'] = "Actualizar";
$l['isb_opt_error'] = "Algo ha sucedido al intentar optimizar el chat...";
$l['isb_reconect'] = 'Ahora estas desconectado. Clic <a href="javascript:void(0);" onclick="javascript: inferno.clear_idle(); return false;">aquí</a> para conectarse de nuevo.';
$l['isb_loading'] = "Cargando...";
$l['isb_shout_error'] = "No se pudo obtener el mensaje...";
$l['isb_shout_cleaned'] = "Chat limpiado correctamente.";
$l['isb_shout_change_style'] = "Tu estilo cambiara al enviar un nuevo mensaje.";
$l['isb_shout_change_style_update'] = "Propiedades de estilo actualizadas.";
$l['isb_shout_wait1'] = "debes esperar ";
$l['isb_shout_wait2'] = " segundo";
$l['isb_shout_wait3'] = "s";
$l['isb_shout_wait4'] = " para enviar otro mensaje.";
$l['isb_shout_no_smilies'] = "No hay caritas que mostrar.";
$l['isb_shout_smilies_error'] = "No se pudieron obtener las caritas...";
$l['isb_shout_notice'] = '<b class="inferno_alert">Noticia del chat:</b> ';
$l['isb_shout_send_error'] = 'Debe ingresar su mensaje antes de enviarlo.';
$l['isb_shout_send_error1'] = 'Has utilizado ';
$l['isb_shout_send_error2'] = ' caracteres. Reduce tu mensaje.';
$l['isb_shout_error_loading'] = 'No se pudieron obtener los mensajes del chat...';
$l['isb_shout_error_userlist'] = 'La lista de usuarios activos no se pudo obtener...';
$l['isb_get_modals'] = '{1} Mensajes Totales: {2}';
$l['isb_banned_list'] = 'Bloqueos Actuales';
$l['isb_unban_error'] = 'Tú no puedes desbloquear usuarios del chat...';
$l['isb_unban_success'] = 'El usuario {1} ha sido desbloqueado del chat.';
$l['isb_unban_user_error'] = 'El usuario seleccionado para esta acción no existe';
$l['isb_modals_unknown'] = '<span>Debes elegir un usuario válido</span>';
$l['isb_get_modals'] = '<span>{1} Mensajes Totales: {2}</span>';
$l['isb_unban_auto'] = 'Desbloqueo automático de su cuenta...<br>Recargue el chat para poder usarlo...<br>';
$l['isb_unban_expires_sin'] = 'El periodo de bloqueo del chat expira el día de hoy';
$l['isb_unban_expires_plu'] = 'El periodo de bloqueo del chat expira en {1} días';
$l['isb_view_all'] = 'Ver todos';
$l['isb_banned_users_list'] = 'Lista de usuarios bloqueados ';
$l['isb_banned_totals'] = 'Total de usuarios bloqueados'; 
$l['isb_banned_user'] = 'Usuario';
$l['isb_banned_by'] = 'Bloqueado por';
$l['isb_banned_reason'] = 'Razón';
$l['isb_banned_unban'] = 'Fecha de desbloqueo';
$l['isb_banned_moderator'] = 'Moderador';
$l['isb_some_moderator'] = 'Un moderador';
$l['isb_unknow'] = 'Desconocido';
$l['isb_never'] = 'Nunca';
$l['isb_unban_now'] = 'Desbloquear ahora';
$l['isb_unban_user_error'] = "<td colspan=\"5\"><span style=\"color:red;\">Tu no puedes desbloquear usuarios...</span></td>";
$l['isb_unban_user_error2'] = "<td colspan=\"5\"><span style=\"color:red;\">El usuario que elegiste desbloquear no existe...</span></td>";
$l['isb_unban_user_success'] = "<td colspan=\"5\"><span style=\"color:green;\">El usuario {1} ha sido desbloqueado del chat.</span></td>";
$l['isb_unban_user_automatic'] = "Desbloqueo de cuenta automatizado...<br>Recargue el chat para empezar a utilizarlo...<br>";
$l['isb_unban_today'] = "hoy";
$l['isb_unban_days'] = "días";
$l['isb_unban_expires'] = "El periodo de su bloqueo de cuenta expira en...{1}";
$l['isb_invalid_user'] = "<span>Debes elegir una cuenta de usuario válida</span>";
$l['isb_user_banned'] = " ha sido bloqueado del chat...";
$l['isb_unban_expires_never'] = "Has sido bloqueado del chat para siempre...";
$l['isb_link'] = "Enlace de";
$l['isb_youtube'] = "Youtube";
$l['isb_title'] = "Título";
$l['isb_channel'] = "Canal";
$l['isb_time'] = "Duración";
$l['isb_views'] = "Visitas";
$l['isb_likes'] = "Me gusta";
$l['isb_into_forums'] = " en el foro ";
$l['isb_my_profile'] = "Mi Perfil";
$l['isb_user_profile'] = "Ver Perfil";
$l['isb_private'] = "Mensajes Privados";
$l['isb_send_private'] = "Enviar Privado";
$l['isb_send_whisper'] = "Enviar Susurro";
$l['isb_whisper'] = "Susurros";
$l['isb_mention'] = "Mencionar Usuario";
$l['isb_twitch_mode'] = "El modo sin conexión necesita {1} votos para iniciar";
$l['isb_twitch_mode_shout'] = "Modo sin conexión activo, se necesitan {1} votos para iniciar éste modo.";
$l['isb_twitch_mode_error'] = "El total de votos que se necesitan para el modo sin conexión es de {1}, debes esperar al siguiente proceso, o deshabilitar y habilitar de nuevo el modo sin conexión e intentarlo de nuevo.";
$l['isb_twitch_mode_disabled'] = "Modo sin conexión deshabilitado, debes habilitarlo para establecer el total de votos para iniciar éste modo.";
$l['isb_twitch_mode_usage'] = "Modo sin conexión habilitado ahora puedes utilizar /{1}[votos] (Para poner un numero start Twitch Mode)";
$l['isb_twitch_mode_enabled'] = "Modo sin conexión habilitado...";
$l['isb_twitch_mode_enabled_error'] = "Tú no puedes habilitar el modo sin conexión...";
$l['isb_twitch_mode_disabled_success'] = "El modo sin conexión ha sido desactivado, todas las preferencias de este modo han sido eliminadas.";
$l['isb_twitch_mode_disabled_error'] = "Modo sin conexión desactivado...";
$l['isb_twitch_mode_disabled_error2'] = "Tú no puedes deshabilitar el modo sin conexión...";
$l['isb_vote_ban_enabled'] = "Modo Ban habilitado";
$l['isb_vote_ban_enabled_error'] = "Tú no puedes deshabilitar el Modo Ban...";
$l['isb_vote_ban_disable'] = "El Modo Ban ha sido desactivado, todas las preferencias de este modo han sido eliminadas.";
$l['isb_vote_ban_disable_on'] = "Modo Ban desactivado";
$l['isb_vote_ban_disable_error'] = "Tú no puedes deshabilitar el Modo Ban...";
$l['isb_vote_ban_total'] = "El total de votos del modo ban ha sido puesto como {1}";
$l['isb_vote_ban_total_msg'] = "El total de votos para habilitar el modo ban es de {1} votos para poder banear a un usuario";
$l['isb_vote_ban_total_msg2'] = "El total de votos ha sido agregado con un total de {1} votos, deberás esperar al siguiente modo ban, o desactivar y activar de nuevo el modo ban.";
$l['isb_vote_ban_total_error'] = "El modo Ban por votos esta desactivado, debes activarlo y colocar un total de votos para banear a un usuario.";
$l['isb_vote_ban_mode_enabled'] = "El modo Ban ha sido habilitado, ahora puedes usar el comando /VoteBanTotal [votos] para elegir el total de votos para banear a un usuario.";
$l['isb_vote_ban_user_error'] = "La id de usuario no existe en nuestra base de datos, verifica e inténtalo de nuevo más tarde...";
$l['isb_vote_ban_total_admin_error'] = "El administrador necesita colocar un total de votos para banear a los usuarios, hasta ese entonces podrás agregar tus votos.";
$l['isb_vote_ban_disabled'] = "Modo Baneo por votos desactivado";
$l['isb_twitch_mode_vote_added'] = "Voto agregado, se necesitan {1} votos más para iniciar el modo sin conexión";
$l['isb_twitch_mode_vote_added_msg'] = "El modo sin restricción require {1} de {2} votos para iniciar.";
$l['isb_twitch_mode_vote_started_msg'] = "El modo sin restricciones ha sido iniciado con un total de {1} de {2} votos.";
$l['isb_twitch_mode_vote_added_error'] = "Sólo puedes votar una ocasión por sesión para el modo sin restricciones de tiempo (Modo sin conexión).";
$l['isb_twitch_mode_vote_added_error2'] = "Necesitas colocar un total de votos para iniciar el conteo de los votos para el modo sin conexión.";
$l['isb_twitch_mode_vote_added_error3'] = "Modo sin conexión deshabilitado, necesitas habilitarlo para colocar el total de votos requeridos para iniciar este modo.";
$l['isb_twitch_mode_error2'] = "Modo sin conexión desactivado";
$l['isb_twitch_mode_error3'] = "El modo sin conexión ha sido desactivado...";
$l['isb_twitch_mode_success'] = "Modo sin conexión activado";
$l['isb_twitch_mode_success2'] = "El modo sin conexión fué activado, ahora puedes usar /TwitchmodeVotes 10 (para colocar un total de 10 votos para iniciar el modo sin conexión)";
$l['isb_vote_ban_mode_error'] = "Modo Ban por Votos desactivado";
$l['isb_vote_ban_mode_error2'] = "El modo ban por votaciones ha sido desactivado...";
$l['isb_vote_ban_mode_success'] = "Modo Ban por Votos activado";
$l['isb_vote_ban_mode_success_msg'] = "Usa /vote_ban_total [total] para que los usuarios usen /vote_ban [uid] y puedan banear por votos a otros usuarios";
$l['isb_vote_ban_mode_success2'] = "El modo ban por votos ha sido activado ...";
$l['isb_admin_error'] = "Tu no eres un administrador para utilizar esta función";
$l['isb_whispers_none'] = "No hay susurros actualmente";
$l['isb_whispers_to'] = "Susurro a {1}";
$l['isb_pm_to'] = "MP a {1}";
